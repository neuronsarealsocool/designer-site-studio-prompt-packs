<?php
/**
 * Alpine Retreat theme setup.
 *
 * @package Alpine Retreat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function alpine_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/site.css' );
}
add_action( 'after_setup_theme', 'alpine_setup' );

function alpine_assets() {
	$theme = wp_get_theme();
	wp_enqueue_style( 'alpine-site', get_theme_file_uri( '/assets/css/site.css' ), array(), $theme->get( 'Version' ) );
	wp_enqueue_script( 'alpine-site', get_theme_file_uri( '/assets/js/site.js' ), array(), $theme->get( 'Version' ), true );
}
add_action( 'wp_enqueue_scripts', 'alpine_assets' );

function alpine_pattern_categories() {
	register_block_pattern_category( 'alpine', array( 'label' => __( 'Alpine Retreat', 'alpine' ) ) );
}
add_action( 'init', 'alpine_pattern_categories' );

