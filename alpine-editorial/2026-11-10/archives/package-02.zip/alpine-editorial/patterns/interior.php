<?php
/**
 * Title: Warm cabin interior
 * Slug: alpine/interior
 * Categories: alpine
 * Inserter: yes
 */
$interior = esc_url( get_theme_file_uri( '/assets/images/47ff0e59edbb41.webp' ) );
?>
<!-- wp:cover {"url":"<?php echo $interior; ?>","dimRatio":25,"overlayColor":"charcoal","minHeight":100,"minHeightUnit":"svh","anchor":"cabin","className":"alpine-interior","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alpine-interior" id="cabin" style="min-height:100svh"><span aria-hidden="true" class="wp-block-cover__background has-charcoal-background-color has-background-dim-25 has-background-dim"></span><img class="wp-block-cover__image-background" alt="A quiet Alpine Retreat lounge with a glowing fireplace and winter lake view" src="<?php echo $interior; ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"className":"alpine-interior-copy","layout":{"type":"constrained"}} --><div class="wp-block-group alpine-interior-copy"><!-- wp:heading --><h2 class="wp-block-heading">Warm wood.<br>Cold outside.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Where the fire crackles<br>and time slows down.</p><!-- /wp:paragraph --></div><!-- /wp:group --></div></div>
<!-- /wp:cover -->

