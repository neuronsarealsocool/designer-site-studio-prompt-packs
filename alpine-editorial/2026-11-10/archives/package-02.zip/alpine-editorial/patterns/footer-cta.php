<?php
/**
 * Title: Booking call to action
 * Slug: alpine/footer-cta
 * Categories: alpine
 * Inserter: yes
 */
$footer_image = esc_url( get_theme_file_uri( '/assets/images/cf198cf9eade49.webp' ) );
?>
<!-- wp:cover {"url":"<?php echo $footer_image; ?>","dimRatio":40,"overlayColor":"charcoal","minHeight":100,"minHeightUnit":"svh","anchor":"book","className":"alpine-booking","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alpine-booking" id="book" style="min-height:100svh"><span aria-hidden="true" class="wp-block-cover__background has-charcoal-background-color has-background-dim-40 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Alpine Retreat cabin glowing among snow-covered pines beneath winter stars" src="<?php echo $footer_image; ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"className":"alpine-booking-copy","layout":{"type":"constrained"}} --><div class="wp-block-group alpine-booking-copy"><!-- wp:heading --><h2 class="wp-block-heading">Slow down.<br>Settle in.<br>Stay awhile.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Winter is waiting.</p><!-- /wp:paragraph --><!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"pine","textColor":"snow","className":"alpine-button"} --><div class="wp-block-button alpine-button"><a class="wp-block-button__link has-snow-color has-pine-background-color has-text-color has-background wp-element-button" href="mailto:stay@alpine.com?subject=Alpine Retreat%20stay%20inquiry">Book your stay</a></div><!-- /wp:button --></div><!-- /wp:buttons --></div><!-- /wp:group --></div></div>
<!-- /wp:cover -->

