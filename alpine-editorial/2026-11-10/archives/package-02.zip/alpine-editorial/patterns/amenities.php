<?php
/**
 * Title: Considered amenities
 * Slug: alpine/amenities
 * Categories: alpine
 * Inserter: yes
 */
$amenities = array(
	array( 'Private setting', 'Forest in every direction', '<path d="M12 3 7 10h3l-4 6h12l-4-6h3Z"/><path d="M12 16v5"/>' ),
	array( 'Cedar sauna', 'Warmth after the cold', '<path d="M4 6h16v12H4z"/><path d="M8 10v4m4-4v4m4-4v4"/><path d="M7 3c1 1 1 2 0 3m5-3c1 1 1 2 0 3"/>' ),
	array( 'Mountain views', 'Alpine horizons, uninterrupted', '<path d="m3 19 6-10 4 6 2-3 6 7Z"/><path d="m7.5 11.5 1.5 1 1.5-1"/>' ),
	array( 'Wood fireplace', 'Cedar split and ready', '<path d="M12 22c4 0 7-3 7-7 0-3-2-6-5-9 0 3-1 4-2 5-1-2-2-3-4-4 0 4-3 5-3 9 0 3 3 6 7 6Z"/><path d="M10 19c-1-2 1-3 2-5 2 2 3 3 2 5"/>' ),
	array( 'Kitchen & pantry', 'Coffee and simple provisions', '<path d="M5 8h11v8a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4Z"/><path d="M16 10h1a3 3 0 0 1 0 6h-1M8 4v2m4-2v2"/>' ),
	array( 'Connected, gently', 'Fast Wi-Fi when needed', '<path d="M5 12a10 10 0 0 1 14 0M8 15a6 6 0 0 1 8 0m-5 3a2 2 0 0 1 2 0"/><circle cx="12" cy="20" r="1"/>' ),
	array( 'Escape kit', 'Books, blankets and snowshoes', '<path d="M4 5h6a2 2 0 0 1 2 2v13a3 3 0 0 0-3-3H4Z"/><path d="M20 5h-6a2 2 0 0 0-2 2v13a3 3 0 0 1 3-3h5Z"/>' ),
);
?>
<!-- wp:group {"tagName":"section","anchor":"amenities","className":"alpine-section alpine-amenities","layout":{"type":"default"}} -->
<section class="wp-block-group alpine-section alpine-amenities" id="amenities"><!-- wp:group {"className":"alpine-amenities-intro","layout":{"type":"constrained"}} --><div class="wp-block-group alpine-amenities-intro"><!-- wp:paragraph {"className":"alpine-section-label"} --><p class="alpine-section-label">03 / Considered comforts</p><!-- /wp:paragraph --><!-- wp:heading --><h2 class="wp-block-heading">Everything you need.<br>Nothing you don’t.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Considered comforts for a simple, restful stay.</p><!-- /wp:paragraph --></div><!-- /wp:group -->
<!-- wp:group {"className":"alpine-amenity-list","layout":{"type":"default"}} --><div class="wp-block-group alpine-amenity-list">
<?php foreach ( $amenities as $amenity ) : ?>
<!-- wp:group {"className":"alpine-amenity-row","layout":{"type":"grid","columnCount":3,"minimumColumnWidth":null}} --><div class="wp-block-group alpine-amenity-row"><!-- wp:html --><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"><?php echo $amenity[2]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG paths. ?></svg><!-- /wp:html --><!-- wp:heading {"level":3} --><h3 class="wp-block-heading"><?php echo esc_html( $amenity[0] ); ?></h3><!-- /wp:heading --><!-- wp:paragraph --><p><?php echo esc_html( $amenity[1] ); ?></p><!-- /wp:paragraph --></div><!-- /wp:group -->
<?php endforeach; ?>
</div><!-- /wp:group --></section>
<!-- /wp:group -->

