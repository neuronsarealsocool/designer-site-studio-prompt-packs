<?php
/**
 * Title: Cabin introduction
 * Slug: alpine/introduction
 * Categories: alpine
 * Inserter: yes
 */
?>
<!-- wp:group {"tagName":"section","anchor":"stay","className":"alpine-section alpine-introduction","layout":{"type":"default"}} -->
<section class="wp-block-group alpine-section alpine-introduction" id="stay"><!-- wp:paragraph {"className":"alpine-section-label"} --><p class="alpine-section-label">01 / The retreat</p><!-- /wp:paragraph --><!-- wp:group {"className":"alpine-intro-main","layout":{"type":"default"}} -->
<div class="wp-block-group alpine-intro-main"><!-- wp:heading --><h2 class="wp-block-heading">A winter cabin built<br>for slow evenings.</h2><!-- /wp:heading --><!-- wp:columns {"className":"alpine-intro-lower"} --><div class="wp-block-columns alpine-intro-lower"><!-- wp:column --><div class="wp-block-column"><!-- wp:paragraph --><p>Warm cedar, quiet rooms and uninterrupted views of the lake. Alpine Retreat is a place to leave the rush behind and make space for what matters.</p><!-- /wp:paragraph --></div><!-- /wp:column --><!-- wp:column --><div class="wp-block-column"><!-- wp:columns {"className":"alpine-stay-meta","isStackedOnMobile":false} --><div class="wp-block-columns is-not-stacked-on-mobile alpine-stay-meta"><!-- wp:column --><div class="wp-block-column"><!-- wp:paragraph --><p>Sleeps<br><strong>4</strong></p><!-- /wp:paragraph --></div><!-- /wp:column --><!-- wp:column --><div class="wp-block-column"><!-- wp:paragraph --><p>Private<br><strong>Sauna</strong></p><!-- /wp:paragraph --></div><!-- /wp:column --><!-- wp:column --><div class="wp-block-column"><!-- wp:paragraph --><p>Indoor<br><strong>Fireplace</strong></p><!-- /wp:paragraph --></div><!-- /wp:column --></div><!-- /wp:columns --></div><!-- /wp:column --></div><!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->

