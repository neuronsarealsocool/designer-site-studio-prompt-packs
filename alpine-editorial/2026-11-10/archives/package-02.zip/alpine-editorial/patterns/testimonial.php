<?php
/**
 * Title: Text testimonial
 * Slug: alpine/testimonial
 * Categories: alpine
 * Inserter: yes
 */
?>
<!-- wp:group {"tagName":"section","className":"alpine-testimonial","layout":{"type":"constrained"}} -->
<section class="wp-block-group alpine-testimonial"><!-- wp:quote --><blockquote class="wp-block-quote"><!-- wp:paragraph --><p>“Alpine Retreat felt like a private world.<br>The kind of place you keep to yourself.”</p><!-- /wp:paragraph --><cite>Maya T. <span>January</span></cite></blockquote><!-- /wp:quote --></section>
<!-- /wp:group -->

