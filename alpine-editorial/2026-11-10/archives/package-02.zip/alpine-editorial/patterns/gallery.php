<?php
/**
 * Title: Moving editorial gallery
 * Slug: alpine/gallery
 * Categories: alpine
 * Inserter: yes
 */
$gallery = array(
	array( '/assets/images/navbar/993e38042c574a.webp', 'A secluded log cabin in warm winter morning light', 1500, 844 ),
	array( '/assets/images/gallery-section/2fe4237b6c3647.webp', 'Stone terrace with a glowing outdoor fireplace', 1000, 1500 ),
	array( '/assets/images/navbar/4c6032fc14314d.webp', 'A small cabin surrounded by a snow-filled pine forest', 1500, 1000 ),
	array( '/assets/images/gallery-section/4540b48175f544.webp', 'Timber cabin beneath pale winter mountains', 1000, 1500 ),
	array( '/assets/images/gallery-section/950e92def32849.webp', 'Warm timber bedroom dressed for winter', 1000, 1500 ),
	array( '/assets/images/gallery-section/d24f0b5f253f4c.webp', 'Cabin lounge overlooking a snow-covered forest', 847, 1500 ),
	array( '/assets/images/gallery-section/34985d00d7a34a.webp', 'Snow-covered log cabin among tall pines', 856, 1500 ),
	array( '/assets/images/navbar/4e89a21213b34f.webp', 'A glowing lakeside cabin in a quiet mountain valley', 1500, 844 ),
	array( '/assets/images/gallery-section/93b07aa9b2164f.webp', 'Cozy bedroom with a fireplace and forest view', 1000, 1500 ),
	array( '/assets/images/gallery-section/f6a3b4c86d0447.webp', 'Bedroom with a fireplace and snowy lake view', 1000, 1500 ),
	array( '/assets/images/gallery-section/2bb0826165984c.webp', 'Soft bed beside a sunlit winter window', 1000, 1500 ),
	array( '/assets/images/gallery-section/4832b2010c6643.webp', 'Airy timber cabin interior and staircase', 1000, 1500 ),
	array( '/assets/images/gallery-section/87af5f090b4443.webp', 'Golden lounge beneath a picture window', 841, 1500 ),
);
?>
<!-- wp:group {"tagName":"section","anchor":"gallery","className":"alpine-gallery-section","layout":{"type":"default"}} -->
<section class="wp-block-group alpine-gallery-section" id="gallery"><!-- wp:group {"className":"alpine-gallery-label-row","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} --><div class="wp-block-group alpine-gallery-label-row"><!-- wp:paragraph {"className":"alpine-section-label"} --><p class="alpine-section-label">02 / Inside Alpine Retreat</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Drag to wander · Hover to pause</p><!-- /wp:paragraph --></div><!-- /wp:group -->
<!-- wp:group {"className":"alpine-film-viewport","layout":{"type":"default"}} --><div class="wp-block-group alpine-film-viewport" aria-label="Alpine Retreat cabin gallery"><!-- wp:group {"className":"alpine-film-track","layout":{"type":"flex","flexWrap":"nowrap"}} --><div class="wp-block-group alpine-film-track"><!-- wp:gallery {"linkTo":"none","className":"alpine-film-sequence"} -->
<figure class="wp-block-gallery has-nested-images columns-default is-cropped alpine-film-sequence">
<?php foreach ( $gallery as $image ) : ?>
<!-- wp:image {"width":"auto","height":"100%","sizeSlug":"full","linkDestination":"none"} --><figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_theme_file_uri( $image[0] ) ); ?>" alt="<?php echo esc_attr( $image[1] ); ?>" width="<?php echo esc_attr( $image[2] ); ?>" height="<?php echo esc_attr( $image[3] ); ?>" style="width:auto;height:100%"/></figure><!-- /wp:image -->
<?php endforeach; ?>
</figure>
<!-- /wp:gallery --></div><!-- /wp:group --></div><!-- /wp:group -->
<!-- wp:group {"className":"alpine-gallery-statement","layout":{"type":"constrained"}} --><div class="wp-block-group alpine-gallery-statement"><!-- wp:heading --><h2 class="wp-block-heading">Every window opens into winter.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Cedar walls, soft light and a place that holds space for doing nothing at all.</p><!-- /wp:paragraph --></div><!-- /wp:group --></section>
<!-- /wp:group -->

