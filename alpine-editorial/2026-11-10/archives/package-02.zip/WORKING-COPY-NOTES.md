This is an adapted private working archive. Neutral names, media filenames and
links differ from earlier snapshots. Required license notices remain intact.
Archive CRC and outer-file SHA-256 were checked; source application builds and
its historical reference-verification hashes were not re-established here.
Use the accompanying working prompt and hosted media manifest for new builds.
