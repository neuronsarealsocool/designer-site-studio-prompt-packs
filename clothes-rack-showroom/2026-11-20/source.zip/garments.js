import * as THREE from './vendor/three.module.js';

const clamp=THREE.MathUtils.clamp;
const geometryCache=new Map();
const textileCanvas=document.createElement('canvas');textileCanvas.width=textileCanvas.height=256;
const tx=textileCanvas.getContext('2d');
const pixels=tx.createImageData(256,256);let random=173;
function noise(){random=(random*16807)%2147483647;return(random-1)/2147483646}
for(let y=0;y<256;y++)for(let x=0;x<256;x++){const i=(y*256+x)*4;const n=123+noise()*16+((x%2===0)?4:0)+((y%3===0)?3:0);pixels.data[i]=n;pixels.data[i+1]=n;pixels.data[i+2]=255;pixels.data[i+3]=255}
tx.putImageData(pixels,0,0);const fabricNormal=new THREE.CanvasTexture(textileCanvas);fabricNormal.wrapS=fabricNormal.wrapT=THREE.RepeatWrapping;fabricNormal.repeat.set(5,7);

function clothMaterial(colour){return new THREE.MeshStandardMaterial({color:colour,roughness:.94,metalness:0,normalMap:fabricNormal,normalScale:new THREE.Vector2(.10,.10),side:THREE.DoubleSide})}
function path(points,material,radius=.008){const c=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));return new THREE.Mesh(new THREE.TubeGeometry(c,Math.max(12,points.length*4),radius,5,false),material)}
function clothZ(x,y,side=1){const lower=clamp(-y/1.8,0,1);return side*(.095+Math.cos(x*2.5)*.045+Math.sin(x*21+y*1.9)*(.012+.022*lower)+Math.sin(x*9-y*3)*.02+Math.sin(y*16+x*4)*.008)+Math.sin(y*1.3)*.035}

function outline(type){
 const s=new THREE.Shape();
 if(type==='pants'){
  s.moveTo(-.42,-.12);s.quadraticCurveTo(0,-.08,.42,-.12);s.lineTo(.48,-.65);s.lineTo(.43,-2.22);s.quadraticCurveTo(.27,-2.28,.13,-2.22);s.lineTo(.06,-.82);s.quadraticCurveTo(0,-.68,-.06,-.82);s.lineTo(-.13,-2.22);s.quadraticCurveTo(-.28,-2.26,-.45,-2.22);s.lineTo(-.48,-.65);s.closePath();return s;
 }
 const long=type!=='tee',crop=type==='hoodie';
 s.moveTo(-.18,-.04);s.quadraticCurveTo(0,-.21,.18,-.04);
 s.quadraticCurveTo(.34,-.08,.49,-.17);
 if(long){s.quadraticCurveTo(.64,-.43,.75,-.72);s.lineTo(.89,-1.64);s.quadraticCurveTo(.80,-1.72,.67,-1.70);s.lineTo(.47,-.83)}
 else{s.lineTo(.87,-.55);s.lineTo(.69,-.79);s.lineTo(.47,-.62)}
 s.quadraticCurveTo(.46,-1.12,.51,crop?-1.55:-1.94);s.quadraticCurveTo(.02,crop?-1.61:-2.0,-.51,crop?-1.55:-1.94);s.quadraticCurveTo(-.47,-1.22,-.47,long?-.83:-.62);
 if(long){s.lineTo(-.67,-1.70);s.quadraticCurveTo(-.80,-1.72,-.89,-1.64);s.lineTo(-.75,-.72);s.quadraticCurveTo(-.64,-.43,-.49,-.17)}
 else{s.lineTo(-.69,-.79);s.lineTo(-.87,-.55);s.lineTo(-.49,-.17)}
 s.quadraticCurveTo(-.32,-.08,-.18,-.04);s.closePath();return s;
}

function subdivide(g,rounds=4){
 let pos=Array.from(g.attributes.position.array);let ids=g.index?Array.from(g.index.array):Array.from({length:pos.length/3},(_,i)=>i);
 for(let n=0;n<rounds;n++){
  const newIds=[],midpoints=new Map();
  function middle(a,b){const key=a<b?a+':'+b:b+':'+a;if(midpoints.has(key))return midpoints.get(key);const v=pos.length/3;pos.push((pos[a*3]+pos[b*3])/2,(pos[a*3+1]+pos[b*3+1])/2,0);midpoints.set(key,v);return v}
  for(let i=0;i<ids.length;i+=3){const[a,b,c]=ids.slice(i,i+3),ab=middle(a,b),bc=middle(b,c),ca=middle(c,a);newIds.push(a,ab,ca,ab,b,bc,ca,bc,c,ab,bc,ca)}ids=newIds;
 }
 const result=new THREE.BufferGeometry();result.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));result.setIndex(ids);return result;
}

function clothGeometry(type,side){const key=type+side;if(geometryCache.has(key))return geometryCache.get(key);const g=subdivide(new THREE.ShapeGeometry(outline(type),12),4);const a=g.attributes.position;const uv=[];for(let i=0;i<a.count;i++){const x=a.getX(i),y=a.getY(i);a.setZ(i,clothZ(x,y,side));uv.push(x+.5,-y/2)}g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.computeVertexNormals();geometryCache.set(key,g);return g}

export function makeGarment(product,index){
 const group=new THREE.Group(),cloth=clothMaterial(product.hex),seam=new THREE.MeshStandardMaterial({color:product.hex,roughness:1});seam.color.multiplyScalar(.70);
 const lightSeam=seam.clone();lightSeam.color.set(product.hex).multiplyScalar(.91);
 const type=product.type;
 for(const side of [1,-1]){const mesh=new THREE.Mesh(clothGeometry(type,side),cloth);mesh.castShadow=true;mesh.receiveShadow=true;group.add(mesh)}
 // The thin perimeter joins the two draped cotton panels.
 const edge=outline(type).getPoints(90);const p=[],ix=[];
 edge.forEach((v,i)=>{p.push(v.x,v.y,clothZ(v.x,v.y,1),v.x,v.y,clothZ(v.x,v.y,-1));if(i<edge.length-1){const a=i*2;ix.push(a,a+1,a+2,a+1,a+3,a+2)}});
 const edgeG=new THREE.BufferGeometry();edgeG.setAttribute('position',new THREE.Float32BufferAttribute(p,3));edgeG.setIndex(ix);edgeG.computeVertexNormals();const edges=new THREE.Mesh(edgeG,cloth);edges.castShadow=true;group.add(edges);
 const line=(coords,m=lightSeam,r=.006)=>group.add(path(coords.map(([x,y])=>[x,y,clothZ(x,y,1)+.008]),m,r));
 if(type==='pants'){
  line([[-.43,-.23],[0,-.22],[.43,-.23]],seam,.013);line([[.02,-.23],[.025,-.53],[-.02,-.65]],seam,.006);
  line([[-.41,-.27],[-.30,-.42],[-.21,-.44]]);line([[.41,-.27],[.30,-.42],[.21,-.44]]);
  line([[-.43,-2.17],[-.29,-2.18],[-.14,-2.17]]);line([[.14,-2.17],[.28,-2.18],[.42,-2.17]]);
  for(const x of [-.33,-.14,.16,.34])line([[x,-.13],[x,-.28]],seam,.009);
 }else{
  const hem=type==='hoodie'?-1.51:-1.90;
  line([[-.49,hem],[-.25,hem-.025],[0,hem-.01],[.25,hem-.025],[.49,hem]],seam,.008);
  line([[-.47,-.25],[-.40,-.45],[-.44,-.70]]);line([[.47,-.25],[.40,-.45],[.44,-.70]]);
  // A rounded neck binding leaves the centre visibly open.
  line([[-.19,-.04],[-.14,-.16],[0,-.22],[.14,-.16],[.19,-.04]],seam,.018);
  if(type==='shirt'){
   line([[0,-.23],[.01,-.6],[.008,-1.2],[0,-1.91]],seam,.013);
   for(let i=0;i<6;i++){const y=-.36-i*.25;const button=new THREE.Mesh(new THREE.SphereGeometry(.014,8,6),seam);button.position.set(.015,y,clothZ(.015,y,1)+.024);button.scale.z=.4;group.add(button)}
   const collar=new THREE.Shape();collar.moveTo(-.17,-.045);collar.lineTo(-.29,-.15);collar.lineTo(-.16,-.34);collar.lineTo(0,-.22);collar.closePath();
   for(const side of [-1,1]){const c=new THREE.Mesh(new THREE.ShapeGeometry(collar),cloth);c.scale.x=side;c.position.z=.18;group.add(c)}
  }
  if(type==='hoodie'){
   const hood=new THREE.Mesh(new THREE.SphereGeometry(.28,24,16,Math.PI,Math.PI,0,Math.PI*.80),cloth);hood.scale.set(.87,1.12,.85);hood.position.set(0,-.10,-.02);hood.castShadow=true;group.add(hood);
   group.add(path([[-.22,-.28,.14],[-.23,-.06,.13],[0,.20,.08],[.23,-.06,.13],[.22,-.28,.14]],cloth,.035));
   line([[-.12,-.22],[-.13,-.38],[-.15,-.68]],seam,.009);line([[.12,-.22],[.13,-.38],[.15,-.66]],seam,.009);
   line([[-.28,-1.13],[-.32,-1.37],[0,-1.39],[.32,-1.37],[.28,-1.13]],lightSeam,.009);
  }else if(index%3!==1){
   const pocket=new THREE.PlaneGeometry(.24,.27,6,8);const pp=pocket.attributes.position;for(let i=0;i<pp.count;i++){const x=pp.getX(i)+.25,y=pp.getY(i)-.65;pp.setXYZ(i,x,y,clothZ(x,y,1)+.016)}pocket.computeVertexNormals();group.add(new THREE.Mesh(pocket,cloth));line([[.13,-.51],[.13,-.77],[.25,-.81],[.37,-.77],[.37,-.51]]);
  }
  if(type!=='tee'){for(const side of [-1,1])line([[side*.68,-1.65],[side*.76,-1.66],[side*.87,-1.61]],seam,.013)}
  if(type==='knit'){
   for(let i=-10;i<=10;i++){const x=i*.041;line([[x,-.30],[x+.008,-.74],[x-.008,-1.2],[x,hem]],lightSeam,.003)}
  }
 }
 // An imperfect wooden hanger and its curved metal hook.
 const wood=new THREE.MeshStandardMaterial({color:'#514233',roughness:.8});const metal=new THREE.MeshStandardMaterial({color:'#b0a898',metalness:.7,roughness:.35});
 const hanger=path([[-.44,-.14,0],[-.2,-.01,0],[0,.14,0],[.2,-.01,0],[.44,-.14,0],[-.44,-.14,0]],wood,.014);group.add(hanger);
 group.add(path([[0,.13,0],[0,.29,0],[.09,.36,0],[.11,.45,0],[.04,.50,0],[-.03,.45,0]],metal,.009));
 group.userData={product,baseAngle:1.33+(index%3-1)*.07,index};group.rotation.y=group.userData.baseAngle;return group;
}

export function makeRack(width=11.6){
 const g=new THREE.Group();const metal=new THREE.MeshStandardMaterial({color:'#bcb5a7',roughness:.36,metalness:.58});
 const rail=new THREE.CatmullRomCurve3([new THREE.Vector3(-width/2,.9,0),new THREE.Vector3(-width/2,4.9,0),new THREE.Vector3(-width/2,5.72,0),new THREE.Vector3(-width/2+.20,5.94,0),new THREE.Vector3(-width/2+.6,5.96,0),new THREE.Vector3(0,5.96,0),new THREE.Vector3(width/2-.6,5.96,0),new THREE.Vector3(width/2-.20,5.94,0),new THREE.Vector3(width/2,5.72,0),new THREE.Vector3(width/2,4.9,0),new THREE.Vector3(width/2,.9,0)],false,'centripetal');
 const tube=new THREE.Mesh(new THREE.TubeGeometry(rail,100,.031,8,false),metal);tube.castShadow=true;g.add(tube);
 const concrete=new THREE.MeshStandardMaterial({color:'#696354',roughness:.91});
 for(const x of [-width/2,width/2]){const base=new THREE.Mesh(new THREE.CylinderGeometry(.07,.36,1.05,36,5),concrete);base.position.set(x,.525,0);base.castShadow=true;base.receiveShadow=true;g.add(base);const cap=new THREE.Mesh(new THREE.CylinderGeometry(.055,.075,.12,16),metal);cap.position.set(x,1.08,0);g.add(cap)}return g;
}
