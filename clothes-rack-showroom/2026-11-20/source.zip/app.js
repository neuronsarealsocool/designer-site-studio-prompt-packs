import * as THREE from './vendor/three.module.js';
import {makeGarment,makeRack} from './garments.js';

const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const colours=[['Coal','#242724'],['Chalk','#e5e3d8'],['Umber','#5e4d3a'],['Ecru','#d0d0b8'],['Indigo','#536c8b'],['Mist','#a7bab9'],['Terracotta','#b9583b'],['Rose clay','#b88482'],['Ochre','#b59b41'],['Sage','#8d9d7d'],['Ink','#222b2c']];
const menTypes=['shirt','hoodie','shirt','tee','pants','knit','tee','hoodie','shirt','knit','pants'];
const womenTypes=['shirt','hoodie','pants','tee','knit','pants','hoodie','tee','knit','shirt','shirt'];
const names={shirt:'Worker shirt',hoodie:'Clay hoodie',tee:'Everyday tee',pants:'Studio trousers',knit:'Mended knit'};
const prices={shirt:125,hoodie:145,tee:65,pants:155,knit:135};
const products=['men','women'].flatMap((category,c)=>colours.map(([colour,hex],i)=>({id:`${category}-${i}`,category,colour,hex,type:(c?womenTypes:menTypes)[i],name:c&&womenTypes[i]==='hoodie'?'Clay cropped zip':`${colour} ${names[(c?womenTypes:menTypes)[i]].toLowerCase()}`,price:prices[(c?womenTypes:menTypes)[i]]})));
let renderer,scene,camera,garments=[],hitTargets=[],active='intro',targetView='store',hovered=null,selected=null,size='M',mobileIndex=5,pointerOn=false,scrollProgress=0,animationTime=0,suppressHomeUntil=0;
let bag=[];try{bag=JSON.parse(localStorage.getItem('ruddo-bag')||'[]').filter(item=>products.some(p=>p.id===item.id)&&['XS','S','M','L','XL'].includes(item.size)&&Number.isInteger(item.quantity)&&item.quantity>0).slice(0,50)}catch{}
const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;
const narrow=()=>innerWidth<700;
const mouse=new THREE.Vector2(5,5),raycaster=new THREE.Raycaster(),projected=new THREE.Vector3();
const lookMouse=new THREE.Vector2(),smoothMouse=new THREE.Vector2(),upAxis=new THREE.Vector3(0,1,0),viewDirection=new THREE.Vector3();
// The rails follow two perpendicular walls meeting at the back of the room.
const rackLayouts={men:{position:new THREE.Vector3(-6.7,0,-1.5),angle:Math.PI/4},women:{position:new THREE.Vector3(6.7,0,-1.5),angle:-Math.PI/4}};
function roomPoint(category,x,y,z){const layout=rackLayouts[category];return new THREE.Vector3(x,y,z).applyAxisAngle(upAxis,layout.angle).add(layout.position)}
const cameraNow=new THREE.Vector3(0,3.9,22),lookNow=new THREE.Vector3(0,2.9,0),lookTarget=new THREE.Vector3();
let cameraTarget=new THREE.Vector3();
const money=n=>`$${n.toFixed(0)}`;
const smooth=t=>t*t*(3-2*t);
function sizeHero(){document.documentElement.style.setProperty('--hero-scale',Math.min(1,innerWidth/1920))}
sizeHero();addEventListener('resize',sizeHero);

function init(){
 scene=new THREE.Scene();
 camera=new THREE.PerspectiveCamera(49,innerWidth/innerHeight,.1,180);camera.position.copy(cameraNow);
 renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
 renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.16;
 $('#world').appendChild(renderer.domElement);
 scene.add(new THREE.HemisphereLight('#ece4d3','#55412b',2.4));
 const sun=new THREE.DirectionalLight('#fff2dc',3.3);sun.position.set(-8,12,8);scene.add(sun);
 const fill=new THREE.DirectionalLight('#f5f0df',1.8);fill.position.set(10,8,5);scene.add(fill);
 const rim=new THREE.DirectionalLight('#e5d9c7',1.4);rim.position.set(2,7,-5);scene.add(rim);
 const floorMaterial=new THREE.ShaderMaterial({vertexShader:'varying vec3 worldPosition;void main(){worldPosition=(modelMatrix*vec4(position,1.0)).xyz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:'varying vec3 worldPosition;void main(){float wallDistance=min(worldPosition.z+9.0+worldPosition.x,worldPosition.z+9.0-worldPosition.x)*.7071;float d=smoothstep(0.0,35.0,wallDistance);gl_FragColor=vec4(mix(vec3(.84,.81,.75),vec3(.68,.62,.56),d),1.0);}'});
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(160,160),floorMaterial);floor.rotation.x=-Math.PI/2;floor.position.y=-.025;scene.add(floor);
 const wallMaterial=new THREE.ShaderMaterial({uniforms:{shade:{value:1}},vertexShader:'varying vec3 vPosition; void main(){vPosition=(modelMatrix*vec4(position,1.0)).xyz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:'uniform float shade;varying vec3 vPosition;void main(){float h=clamp(vPosition.y/15.0,0.0,1.0);vec3 low=vec3(.84,.81,.75);vec3 mid=vec3(.29,.22,.16);vec3 high=vec3(.068,.044,.028);vec3 c=mix(low,mid,smoothstep(.0,.52,h));c=mix(c,high,smoothstep(.25,.73,h));gl_FragColor=vec4(c*shade,1.0);}',side:THREE.DoubleSide});
 for(const side of [-1,1]){const material=wallMaterial.clone();material.uniforms.shade.value=side<0?.97:1;const wall=new THREE.Mesh(new THREE.PlaneGeometry(Math.sqrt(2)*40,60),material);wall.position.set(side*20,23,11);wall.rotation.y=-side*Math.PI/4;scene.add(wall)}
 // Soft ambient contact shadows, including beneath each individual hanging piece.
 const shadowCanvas=document.createElement('canvas');shadowCanvas.width=shadowCanvas.height=128;const ctx=shadowCanvas.getContext('2d');const gradient=ctx.createRadialGradient(64,64,0,64,64,64);gradient.addColorStop(0,'rgba(40,30,18,.27)');gradient.addColorStop(.45,'rgba(40,30,18,.12)');gradient.addColorStop(1,'rgba(40,30,18,0)');ctx.fillStyle=gradient;ctx.fillRect(0,0,128,128);const shadowTex=new THREE.CanvasTexture(shadowCanvas);
 const shadowMat=new THREE.MeshBasicMaterial({map:shadowTex,transparent:true,depthWrite:false});
 for(const [category,layout] of Object.entries(rackLayouts)){
  const wallRail=new THREE.Group();wallRail.position.copy(layout.position);wallRail.rotation.y=layout.angle;scene.add(wallRail);
  wallRail.add(makeRack());
  products.filter(p=>p.category===category).forEach((p,i)=>{
   const garment=makeGarment(p,i);garment.position.set(-4.95+i*.99,5.19,.02);garment.scale.setScalar(1.4);garment.userData.origin=garment.position.clone();wallRail.add(garment);garments.push(garment);
   const pick=new THREE.Mesh(new THREE.BoxGeometry(.78,3.4,.95),new THREE.MeshBasicMaterial({visible:false}));pick.position.copy(garment.position).add(new THREE.Vector3(0,-1.35,0));pick.userData.garment=garment;wallRail.add(pick);hitTargets.push(pick);
   const shadow=new THREE.Mesh(new THREE.PlaneGeometry(1.9,2.5),shadowMat);shadow.rotation.x=-Math.PI/2;shadow.position.set(garment.position.x,.006,.05);wallRail.add(shadow);
  });
  for(const x of [-5.8,5.8]){const shadow=new THREE.Mesh(new THREE.PlaneGeometry(2.1,3.1),shadowMat);shadow.rotation.x=-Math.PI/2;shadow.position.set(x,.008,.1);wallRail.add(shadow)}
 }
 window.addEventListener('pointermove',e=>{if(e.pointerType==='touch')return;mouse.set(e.clientX/innerWidth*2-1,-e.clientY/innerHeight*2+1);pointerOn=e.target===renderer.domElement;if(pointerOn)lookMouse.copy(mouse)});
 document.documentElement.addEventListener('pointerleave',()=>lookMouse.set(0,0));
 window.addEventListener('blur',()=>{lookMouse.set(0,0);pointerOn=false;hovered=null});
 renderer.domElement.addEventListener('pointerleave',()=>{pointerOn=false;hovered=null});
 renderer.domElement.addEventListener('click',()=>{if(hovered&&active!=='intro')openProduct(hovered.userData.product)});
 addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
 renderer.setAnimationLoop(animate);
 document.body.dataset.ready='true';
}

function scroll(){
 scrollProgress=Math.min(1,scrollY/(innerHeight*1.2));
 if(active==='intro'&&scrollProgress>.42)enterStore(false);
 if(active!=='intro'&&scrollProgress<.08&&performance.now()>suppressHomeUntil&&!document.querySelector('dialog[open]'))home(false);
}
addEventListener('scroll',scroll,{passive:true});

function enterStore(moveScroll=true){
 if(active==='intro'){active='store';targetView='store';document.body.classList.add('entered');$('#back').hidden=false;$('#store-nav').hidden=false;$('#browse-hint').hidden=false;updateNav()}
 if(moveScroll){suppressHomeUntil=performance.now()+1500;window.scrollTo({top:innerHeight*1.2,behavior:reducedMotion?'instant':'smooth'})}
}
function goView(view){
 enterStore();targetView=view;active=view;hovered=null;selected=null;mobileIndex=5;lookMouse.set(0,0);pointerOn=false;
 $('#collection-title').textContent=view==='store'?'':`${view} / workwear`;
 $('#mobile-pieces').hidden=view==='store';
 $('#browse-hint').textContent=view==='store'?'Choose a collection below':narrow()?'Swipe through the rail / tap to explore':'Move to explore / select a piece';
 updateNav();
}
function updateNav(){$$('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===targetView);b.setAttribute('aria-pressed',String(b.dataset.view===targetView))})}
function home(moveScroll=true){active='intro';hovered=null;selected=null;document.body.classList.remove('entered');$('#back').hidden=true;$('#store-nav').hidden=true;$('#browse-hint').hidden=true;$('#mobile-pieces').hidden=true;$('#collection-title').textContent='';$('#garment-label').hidden=true;if(moveScroll)window.scrollTo({top:0,behavior:'instant'})}

let lastTime=0;
function animate(time){
 const dt=Math.min(.05,(time-lastTime)/1000||.016);lastTime=time;animationTime=time/1000;
 const factor=reducedMotion?1:1-Math.exp(-dt*4.2);
 const p=smooth(scrollProgress);
 if(active==='intro'){cameraTarget.set(0,3.9-p*.4,narrow()?31-p*3:22-p*4);lookTarget.set(0,5.3-p*2.4,0)}
 else if(targetView==='store'){cameraTarget.set(0,3.65,narrow()?29:17.5);lookTarget.set(0,2.9,-2.0)}
 else{const x=narrow()?-4.95+mobileIndex*.99:0;cameraTarget.copy(roomPoint(targetView,x,3.35,narrow()?10.7:9.8));lookTarget.copy(roomPoint(targetView,x,3.0,0))}
 if(selected){const origin=selected.userData.origin,category=selected.userData.product.category;cameraTarget.copy(roomPoint(category,origin.x+(narrow()?0:1.3),3.6,narrow()?8:7));lookTarget.copy(roomPoint(category,origin.x+(narrow()?0:1.3),3.5,0))}
 // Cursor position changes camera yaw and pitch, rather than sliding the room.
 const allowLook=!reducedMotion&&!narrow()&&!selected&&!document.querySelector('dialog[open]');
 smoothMouse.lerp(allowLook?lookMouse:new THREE.Vector2(),factor);
 const yawRange=active==='intro'?.14:targetView==='store'?.38:.14;
 viewDirection.copy(lookTarget).sub(cameraTarget).applyAxisAngle(upAxis,-smoothMouse.x*yawRange);
 viewDirection.y+=smoothMouse.y*viewDirection.length()*(active==='intro'?.045:targetView==='store'?.065:.035);
 lookTarget.copy(cameraTarget).add(viewDirection);
 cameraNow.lerp(cameraTarget,factor);lookNow.lerp(lookTarget,factor);camera.position.copy(cameraNow);camera.lookAt(lookNow);
 if(active!=='intro'&&pointerOn&&!selected&&!document.querySelector('dialog[open]')){
  raycaster.setFromCamera(mouse,camera);const hits=raycaster.intersectObjects(hitTargets);hovered=hits.length?hits[0].object.userData.garment:null;
  if(hovered&&targetView!=='store'&&hovered.userData.product.category!==targetView)hovered=null;
 }
 renderer.domElement.style.cursor=hovered&&active!=='intro'?'pointer':'default';
 let focus=selected||hovered;
 for(const g of garments){
  const chosen=g===focus;const base=g.userData.origin;
  g.rotation.y=THREE.MathUtils.lerp(g.rotation.y,chosen?-.025:g.userData.baseAngle,factor*1.5);
  g.position.z=THREE.MathUtils.lerp(g.position.z,chosen?1.25:base.z,factor);
  const sway=reducedMotion?0:Math.sin(animationTime*.7+g.userData.index)*.008;
  g.rotation.z=THREE.MathUtils.lerp(g.rotation.z,chosen?0:sway,factor);
 }
 const label=$('#garment-label');
 if(focus&&active!=='intro'&&!selected){const h=focus.userData.product.type==='pants'?3.3:2.95;projected.copy(roomPoint(focus.userData.product.category,focus.position.x,focus.position.y-h,focus.position.z+.1)).project(camera);const x=(projected.x*.5+.5)*innerWidth,y=(-projected.y*.5+.5)*innerHeight;label.hidden=x<30||x>innerWidth-30||y>innerHeight-100;label.style.left=`${Math.max(100,Math.min(innerWidth-100,x))}px`;label.style.top=`${Math.max(150,Math.min(innerHeight-120,y+10))}px`;label.textContent=focus.userData.product.name}
 else label.hidden=true;
 renderer.render(scene,camera);
}

function openDialog(id){const d=$('#'+id);if(!d.open)d.showModal();document.body.classList.add('dialog-open')}
function closeDialog(id){$('#'+id).close();document.body.classList.remove('dialog-open');if(id==='product-panel'){selected=null;hovered=null}}
function openProduct(product){
 selected=garments.find(g=>g.userData.product.id===product.id)||null;hovered=null;size='M';
 $('#product-category').textContent=`${product.category} / workwear · SS27`;
 $('#product-name').textContent=product.name;$('#product-price').textContent=money(product.price);$('#product-colour').textContent=product.colour;
 $('#product-feedback').textContent='';$('#add-to-cart').disabled=false;$('#product-panel').dataset.product=product.id;
 $$('[data-size]').forEach(b=>{b.classList.toggle('selected',b.dataset.size==='M');b.setAttribute('aria-pressed',String(b.dataset.size==='M'))});openDialog('product-panel');
}
$$('[data-close]').forEach(b=>b.onclick=()=>closeDialog(b.dataset.close));
$$('dialog').forEach(d=>{d.addEventListener('cancel',()=>{selected=null;hovered=null;document.body.classList.remove('dialog-open')});d.addEventListener('click',e=>{if(e.target===d&&e.clientX<d.getBoundingClientRect().left)closeDialog(d.id)})});
$('#menu-button').onclick=()=>{openDialog('menu-panel');$('#menu-button').setAttribute('aria-expanded','true')};
$('#menu-panel').addEventListener('close',()=>$('#menu-button').setAttribute('aria-expanded','false'));
$('#cart-button').onclick=()=>{renderBag();openDialog('cart-panel')};
$$('[data-view]').forEach(b=>b.onclick=()=>goView(b.dataset.view));
$$('[data-go]').forEach(b=>b.onclick=()=>{closeDialog('menu-panel');goView(b.dataset.go)});
$('.brand').onclick=()=>home();$('#back').onclick=()=>targetView!=='store'?goView('store'):home();$('#walk').onclick=()=>enterStore();$('#enter').onclick=()=>enterStore();
$$('[data-size]').forEach(b=>b.onclick=()=>{size=b.dataset.size;$$('[data-size]').forEach(item=>{item.classList.toggle('selected',item===b);item.setAttribute('aria-pressed',String(item===b))})});
$('#add-to-cart').onclick=()=>{
 const id=$('#product-panel').dataset.product;const item=bag.find(p=>p.id===id&&p.size===size);if(item)item.quantity++;else bag.push({id,size,quantity:1});saveBag();$('#product-feedback').textContent=`Added to your bag — size ${size}.`;$('#add-to-cart').disabled=true;setTimeout(()=>$('#add-to-cart').disabled=false,500);
};
$('#continue').onclick=()=>closeDialog('cart-panel');
function saveBag(){try{localStorage.setItem('ruddo-bag',JSON.stringify(bag))}catch{}renderBag()}
function renderBag(){
 const count=bag.reduce((n,p)=>n+p.quantity,0);$('#cart-count').textContent=count?` (${count})`:'';$('#bag-quantity').textContent=`(${count})`;$('#cart-footer').hidden=!count;
 const container=$('#cart-items');container.replaceChildren();let total=0;
 if(!count){const heading=document.createElement('p');heading.className='empty-bag';heading.textContent='A little room for something good.';const text=document.createElement('p');text.className='empty-copy';text.textContent='Explore the rails and find your everyday piece.';container.append(heading,text)}
 bag.forEach((entry,index)=>{const p=products.find(p=>p.id===entry.id);if(!p)return;total+=p.price*entry.quantity;const item=document.createElement('div');item.className='bag-item';const chip=document.createElement('div');chip.className='bag-colour';chip.style.setProperty('--garment',p.hex);chip.setAttribute('aria-hidden','true');const info=document.createElement('div');const name=document.createElement('p');name.className='bag-name';name.textContent=p.name;const meta=document.createElement('p');meta.className='bag-meta';meta.textContent=`${p.colour} / ${entry.size} / Qty ${entry.quantity}`;const remove=document.createElement('button');remove.className='remove-item';remove.textContent='Remove';remove.setAttribute('aria-label',`Remove ${p.name}, size ${entry.size}`);remove.onclick=()=>{bag.splice(index,1);saveBag()};info.append(name,meta,remove);const price=document.createElement('span');price.className='bag-price';price.textContent=money(p.price*entry.quantity);item.append(chip,info,price);container.append(item)});
 $('#cart-total').textContent=money(total);
}
function mobileSelect(direction){const subset=garments.filter(g=>g.userData.product.category===targetView);if(!subset.length){goView('men');return}mobileIndex=(mobileIndex+direction+subset.length)%subset.length;hovered=subset[mobileIndex];pointerOn=false}
$('#previous').onclick=()=>mobileSelect(-1);$('#next').onclick=()=>mobileSelect(1);$('#inspect').onclick=()=>{mobileSelect(0);if(hovered)openProduct(hovered.userData.product)};
let touchStart=null;
$('#world').addEventListener('touchstart',e=>{touchStart=e.touches[0].clientX},{passive:true});
$('#world').addEventListener('touchend',e=>{if(touchStart===null||targetView==='store')return;const delta=e.changedTouches[0].clientX-touchStart;if(Math.abs(delta)>40)mobileSelect(delta>0?-1:1);touchStart=null},{passive:true});
$('#fallback-browse').onclick=()=>{enterStore();openProduct(products[5])};
renderBag();
try{init();scroll()}catch(error){console.error('Showroom could not load',error);$('#fallback').hidden=false;document.body.dataset.ready='fallback'}
