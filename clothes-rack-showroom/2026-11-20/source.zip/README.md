# Clothes Rack Showroom

An independently authored Three.js clothing showroom. Two clothing rails occupy
perpendicular walls; scroll moves into the room, desktop pointer movement changes
camera yaw/pitch, and Store/Men/Women controls move between views.

## Run

Extract this archive, open a terminal in its folder, run
`python -m http.server 5188`, and visit http://localhost:5188.
No package installation, account, API key, paid generation or build is required.
Serve over HTTP so browser ES modules and local fonts load correctly.

Choose a collection, explore a piece, select a size and add it to the demo bag.
Use the arrow controls on touch screens or keyboard. Escape and the visible close
controls dismiss dialogs. Bag state is stored in the browser.

The clothing is procedural approximation geometry; original website source and
original garment models were not supplied. Products and prices are illustrative.
Checkout is not connected and no payment is taken. The original reference recording
is not included. The public example is https://ruddo-clay-showroom.neuronsarealsocool.chatgpt.site/.

## Files and rights

`index.html`, `style.css`, `app.js` and `garments.js` are the portable implementation.
Keep `vendor/three.module.js` with `vendor/THREE-LICENSE.txt` and
`fonts/outfit.ttf` with `fonts/OFL.txt`. The original authored implementation is
covered by `LICENSE.txt`; third-party components keep their own licenses. Brand
identity and reference material do not receive new rights through this archive.

Use the full pack prompt for detailed camera, geometry, typography, interaction,
adaptation and production acceptance guidance. WordPress is optional. Replicate is
the default for genuinely new generated media, with model/budget agreement and chat
approval before publication. This kit itself needs no media generation.
