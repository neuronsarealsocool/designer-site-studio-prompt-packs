<?php
/**
 * Coffee theme bootstrap and data helpers.
 *
 * @package Coffee
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LAYER_VERSION', '1.0.5' );

function layer_theme_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}
add_action( 'after_setup_theme', 'layer_theme_setup' );

function layer_enqueue_theme_style() {
	wp_enqueue_style( 'coffee-theme', get_stylesheet_uri(), array(), LAYER_VERSION );
}
add_action( 'wp_enqueue_scripts', 'layer_enqueue_theme_style' );

function layer_register_blocks() {
	register_block_type( get_theme_file_path( 'blocks/drink-selector' ) );
}
add_action( 'init', 'layer_register_blocks' );

function layer_drink_selector_editor_settings() {
	$background_path = get_theme_file_path( 'assets/background/0daa40b0d49544.png' );
	$background_url  = add_query_arg( 'ver', (string) filemtime( $background_path ), get_theme_file_uri( 'assets/background/0daa40b0d49544.png' ) );
	$settings = array(
		'themeUrl'   => get_theme_file_uri(),
		'background' => $background_url,
		'wooActive'  => class_exists( 'WooCommerce' ),
		'defaults'   => array(),
	);
	foreach ( layer_default_drinks() as $drink ) {
		$settings['defaults'][] = array(
			'label'         => $drink['label'],
			'productId'     => 0,
			'cupId'         => 0,
			'cupUrl'        => get_theme_file_uri( 'assets/cups/' . $drink['cup'] ),
			'ingredientId'  => 0,
			'ingredientUrl' => get_theme_file_uri( 'assets/ingredients/' . $drink['ingredient'] ),
			'sizeLabels'    => array( '12 OZ', '16 OZ', '20 OZ' ),
		);
	}
	wp_localize_script( 'layer-drink-selector-editor-script', 'layerDrinkSelectorEditor', $settings );
}
add_action( 'enqueue_block_editor_assets', 'layer_drink_selector_editor_settings' );

function layer_register_pattern_metadata() {
	register_block_pattern_category( 'layer', array( 'label' => __( 'Coffee', 'layer' ) ) );
}
add_action( 'init', 'layer_register_pattern_metadata' );

function layer_block_categories( $categories ) {
	array_unshift( $categories, array( 'slug' => 'layer', 'title' => __( 'Coffee', 'layer' ) ) );
	return $categories;
}
add_filter( 'block_categories_all', 'layer_block_categories' );

/**
 * Canonical drink data. Prices are fixture-only fallbacks and are replaced by
 * live variation data whenever a WooCommerce product is mapped.
 */
function layer_default_drinks() {
	return array(
		array( 'label' => 'Caramel Cloud', 'cup' => '1a3a5c869b0243.png', 'ingredient' => '829205e4ca764d.png', 'prices' => array( 5.50, 6.25, 7.00 ) ),
		array( 'label' => 'Mocha Cream', 'cup' => '6312e08d7f7641.png', 'ingredient' => '2d82ae03b82949.png', 'prices' => array( 5.75, 6.50, 7.25 ) ),
		array( 'label' => 'Strawberry Cold Foam', 'cup' => '0d762ddc67f741.png', 'ingredient' => 'c1dea116eef44f.png', 'prices' => array( 5.75, 6.50, 7.25 ) ),
		array( 'label' => 'Pistachio Oat Latte', 'cup' => 'e77a25d974ab4a.png', 'ingredient' => '3f3be5b886924f.png', 'prices' => array( 6.00, 6.75, 7.50 ) ),
		array( 'label' => 'Brown Sugar Latte', 'cup' => '9f43ed877a7940.png', 'ingredient' => 'cf53b1e010f54c.png', 'prices' => array( 5.50, 6.25, 7.00 ) ),
	);
}

function layer_normalize_size_token( $value ) {
	$value = strtolower( wp_strip_all_tags( (string) $value ) );
	$value = str_replace( 'ounces', 'oz', $value );
	$value = preg_replace( '/[^a-z0-9]/', '', $value );
	return str_replace( 'oz', '', $value );
}

function layer_resolve_image_url( $entry, $url_key, $default_subpath ) {
	if ( ! empty( $entry[ $url_key ] ) ) {
		return esc_url_raw( $entry[ $url_key ] );
	}
	return get_theme_file_uri( $default_subpath );
}

function layer_fixture_sizes( $labels, $prices ) {
	$sizes = array();
	foreach ( $labels as $position => $label ) {
		$price   = isset( $prices[ $position ] ) ? (float) $prices[ $position ] : 0;
		$sizes[] = array(
			'label'          => sanitize_text_field( $label ),
			'attributeName'  => '',
			'attributeValue' => '',
			'variationId'    => 0,
			'price'          => $price,
			'priceHtml'      => '$' . number_format( $price, 2 ),
			'inStock'        => true,
			'purchasable'    => false,
		);
	}
	return $sizes;
}

function layer_live_variation_sizes( $product, $labels ) {
	$sizes      = array();
	$variations = $product->get_available_variations();

	foreach ( $labels as $label ) {
		$match       = null;
		$wanted      = layer_normalize_size_token( $label );
		$attribute_n = '';
		$attribute_v = '';

		foreach ( $variations as $variation ) {
			$candidate_name  = '';
			$candidate_value = '';
			foreach ( $variation['attributes'] as $name => $value ) {
				if ( false !== strpos( $name, 'size' ) || '' === $candidate_name ) {
					$candidate_name  = $name;
					$candidate_value = $value;
				}
				if ( false !== strpos( $name, 'size' ) ) {
					break;
				}
			}
			if ( layer_normalize_size_token( $candidate_value ) === $wanted ) {
				$match       = $variation;
				$attribute_n = $candidate_name;
				$attribute_v = $candidate_value;
				break;
			}
		}

		if ( $match ) {
			$variation_product = wc_get_product( $match['variation_id'] );
			$in_stock          = $variation_product && $variation_product->is_in_stock();
			$purchasable       = $variation_product && $variation_product->is_purchasable() && $in_stock && ! empty( $match['variation_is_active'] );
			$sizes[]           = array(
				'label'          => sanitize_text_field( $label ),
				'attributeName'  => sanitize_key( $attribute_n ),
				'attributeValue' => sanitize_title( $attribute_v ),
				'variationId'    => (int) $match['variation_id'],
				'price'          => (float) $match['display_price'],
				'priceHtml'      => wp_kses_post( $variation_product->get_price_html() ),
				'inStock'        => $in_stock,
				'purchasable'    => $purchasable,
			);
		} else {
			$sizes[] = array(
				'label'          => sanitize_text_field( $label ),
				'attributeName'  => '',
				'attributeValue' => '',
				'variationId'    => 0,
				'price'          => 0,
				'priceHtml'      => __( 'Unavailable', 'layer' ),
				'inStock'        => false,
				'purchasable'    => false,
			);
		}
	}

	return $sizes;
}

function layer_resolve_drink( $entry, $index ) {
	$defaults    = layer_default_drinks();
	$fallback    = isset( $defaults[ $index ] ) ? $defaults[ $index ] : $defaults[0];
	$size_labels = ! empty( $entry['sizeLabels'] ) && is_array( $entry['sizeLabels'] ) ? array_slice( $entry['sizeLabels'], 0, 3 ) : array( '12 OZ', '16 OZ', '20 OZ' );
	$size_labels = array_pad( $size_labels, 3, '' );
	$product_id  = ! empty( $entry['productId'] ) ? absint( $entry['productId'] ) : 0;
	$product     = function_exists( 'wc_get_product' ) && $product_id ? wc_get_product( $product_id ) : false;
	$label       = ! empty( $entry['label'] ) ? sanitize_text_field( $entry['label'] ) : $fallback['label'];
	$sizes       = layer_fixture_sizes( $size_labels, $fallback['prices'] );
	$setup       = '';

	if ( $product && $product->is_type( 'variable' ) ) {
		$sizes = layer_live_variation_sizes( $product, $size_labels );
	} elseif ( $product_id && function_exists( 'wc_get_product' ) ) {
		$setup = __( 'Choose a variable WooCommerce product with Size variations.', 'layer' );
	} elseif ( ! class_exists( 'WooCommerce' ) ) {
		$setup = __( 'WooCommerce is inactive. Preview prices are shown; purchasing is disabled.', 'layer' );
	} else {
		$setup = __( 'Map this drink to a WooCommerce variable product in the block editor.', 'layer' );
	}

	return array(
		'label'          => $label,
		'wooName'        => $product ? $product->get_name() : '',
		'productId'      => $product ? $product->get_id() : 0,
		'cup'            => layer_resolve_image_url( $entry, 'cupUrl', 'assets/cups/' . $fallback['cup'] ),
		'ingredient'     => layer_resolve_image_url( $entry, 'ingredientUrl', 'assets/ingredients/' . $fallback['ingredient'] ),
		'sizes'          => $sizes,
		'setupMessage'   => $setup,
		'productUrl'     => $product ? $product->get_permalink() : '',
	);
}

function layer_cart_link_markup() {
	$count = function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	$url   = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' );
	return sprintf(
		'<a class="layer-cart-link" href="%1$s" aria-label="%2$s"><svg viewBox="0 0 24 27" aria-hidden="true"><path d="M4 8.5h16l-1 16H5zM8 9V6a4 4 0 0 1 8 0v3"/></svg><span class="layer-cart-count">%3$d</span></a>',
		esc_url( $url ),
		esc_attr( sprintf( _n( 'Cart, %d item', 'Cart, %d items', $count, 'layer' ), $count ) ),
		(int) $count
	);
}
add_shortcode( 'layer_cart_link', 'layer_cart_link_markup' );

function layer_cart_fragments( $fragments ) {
	$fragments['a.layer-cart-link'] = layer_cart_link_markup();
	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'layer_cart_fragments' );

function layer_woocommerce_admin_notice() {
	if ( ! class_exists( 'WooCommerce' ) && current_user_can( 'activate_plugins' ) ) {
		echo '<div class="notice notice-warning"><p>' . esc_html__( 'Coffee is active. Install and activate WooCommerce to enable live product mapping, variations, cart, and checkout.', 'layer' ) . '</p></div>';
	}
}
add_action( 'admin_notices', 'layer_woocommerce_admin_notice' );
