# Coffee block theme

Coffee is a WordPress block theme for a fictional specialty-coffee WooCommerce store. It includes a dynamic `coffee/drink-selector` block, a composed front-page template, editable editorial patterns, and copied production assets.

## Installation

1. Install and activate WooCommerce.
2. Import `layer-products.csv` from **Products → All Products → Import**.
3. Upload `coffee-theme.zip` from **Appearance → Themes → Add New → Upload Theme** and activate Coffee.
4. Edit the front page, select the Coffee Drink Selector block, and map each drink to its imported variable product.
5. Confirm each product exposes a Size attribute with 12 OZ, 16 OZ, and 20 OZ variations.

The block safely previews fixture prices when WooCommerce is inactive or a mapping is missing, but purchasing remains disabled until a valid variable product is mapped.

## Editing

Use the block inspector to choose the default drink, reorder/add/remove entries, map products, choose cup and ingredient media, edit labels and size labels, and adjust the restrained accent/text colors. Lower homepage sections use standard Gutenberg blocks.

## Interaction

The controller preloads all cup and ingredient imagery before unlocking navigation. It animates one shared circular ingredient sequence, keeps active and pending product state separate, and commits product data only once the destination ingredient is hidden at the center. Two identically positioned cup layers crossfade over 210 ms.
