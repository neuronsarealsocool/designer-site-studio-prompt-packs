<?php
/**
 * Dynamic render callback for the Coffee drink selector.
 *
 * @package Coffee
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$defaults       = layer_default_drinks();
$entries        = ! empty( $attributes['drinks'] ) && is_array( $attributes['drinks'] ) ? $attributes['drinks'] : array();
$button_prefix  = ! empty( $attributes['buttonPrefix'] ) ? sanitize_text_field( $attributes['buttonPrefix'] ) : __( 'ADD TO CART', 'layer' );
$accent_color   = ! empty( $attributes['accentColor'] ) && sanitize_hex_color( $attributes['accentColor'] ) ? sanitize_hex_color( $attributes['accentColor'] ) : '#a64f18';
$text_color     = ! empty( $attributes['textColor'] ) && sanitize_hex_color( $attributes['textColor'] ) ? sanitize_hex_color( $attributes['textColor'] ) : '#201812';

if ( empty( $entries ) ) {
	foreach ( $defaults as $default ) {
		$entries[] = array(
			'label'      => $default['label'],
			'productId'  => 0,
			'sizeLabels' => array( '12 OZ', '16 OZ', '20 OZ' ),
		);
	}
}

$drinks = array();
foreach ( $entries as $position => $entry ) {
	$drinks[] = layer_resolve_drink( is_array( $entry ) ? $entry : array(), $position );
}

$count         = count( $drinks );
$default_index = isset( $attributes['defaultIndex'] ) ? absint( $attributes['defaultIndex'] ) : 1;
$default_index = $count ? min( $default_index, $count - 1 ) : 0;
$initial       = $drinks[ $default_index ];
$initial_size  = isset( $initial['sizes'][1] ) ? $initial['sizes'][1] : $initial['sizes'][0];
$block_id      = wp_unique_id( 'layer-selector-' );
$cart_url      = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' );
$background_path = get_theme_file_path( 'assets/background/0daa40b0d49544.png' );
$background      = add_query_arg( 'ver', (string) filemtime( $background_path ), get_theme_file_uri( 'assets/background/0daa40b0d49544.png' ) );
$config        = array(
	'drinks'        => $drinks,
	'defaultIndex'  => $default_index,
	'buttonPrefix'  => $button_prefix,
	'cartUrl'       => $cart_url,
	'travelMs'      => 560,
	'crossfadeMs'   => 220,
	'reducedFadeMs' => 130,
);
$wrapper_style = sprintf(
	'--layer-accent:%1$s;--layer-text:%2$s;--layer-background:url(%3$s)',
	$accent_color,
	$text_color,
	esc_url( $background )
);

if ( ! function_exists( 'layer_slot_for_difference' ) ) {
	function layer_slot_for_difference( $difference, $total ) {
		if ( 0 === $difference ) {
			return 0;
		}
		$half = floor( $total / 2 );
		return $difference <= $half ? $difference : $difference - $total;
	}
}
?>
<section
	id="<?php echo esc_attr( $block_id ); ?>"
	<?php echo get_block_wrapper_attributes( array( 'class' => 'layer-drink-selector is-loading is-locked', 'tabindex' => '0', 'aria-roledescription' => __( 'product carousel', 'layer' ), 'style' => $wrapper_style ) ); ?>
>
	<script type="application/json" class="layer-selector-data"><?php echo wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?></script>
	<div class="layer-hero-canvas">
		<svg class="layer-curve" viewBox="0 0 1600 900" preserveAspectRatio="none" aria-hidden="true">
			<path d="M70 350 C390 570 1210 570 1530 342" />
		</svg>

		<button class="layer-arrow layer-arrow-prev" type="button" aria-label="<?php esc_attr_e( 'Previous drink', 'layer' ); ?>" disabled><span aria-hidden="true">‹</span></button>
		<button class="layer-arrow layer-arrow-next" type="button" aria-label="<?php esc_attr_e( 'Next drink', 'layer' ); ?>" disabled><span aria-hidden="true">›</span></button>

		<div class="layer-ingredients" aria-label="<?php esc_attr_e( 'Choose a drink', 'layer' ); ?>">
			<?php foreach ( $drinks as $index => $drink ) :
				$difference = ( $index - $default_index + $count ) % $count;
				$slot       = layer_slot_for_difference( $difference, $count );
				?>
				<button
					class="layer-ingredient<?php echo 0 === $slot ? ' is-center' : ''; ?>"
					type="button"
					data-index="<?php echo esc_attr( $index ); ?>"
					data-slot="<?php echo esc_attr( $slot ); ?>"
					aria-label="<?php echo esc_attr( sprintf( __( 'Select %s', 'layer' ), $drink['label'] ) ); ?>"
					<?php disabled( 0 === $slot ); ?>
				>
					<img src="<?php echo esc_url( $drink['ingredient'] ); ?>" alt="" width="1600" height="2000" loading="eager" decoding="async">
					<span class="layer-position-dot" aria-hidden="true"></span>
					<span class="layer-ingredient-label"><?php echo esc_html( $drink['label'] ); ?></span>
				</button>
			<?php endforeach; ?>
		</div>

		<div class="layer-cup-stage" aria-hidden="true">
			<div class="layer-cup-layers">
				<img class="layer-cup layer-cup-a is-visible" src="<?php echo esc_url( $initial['cup'] ); ?>" alt="" width="2400" height="3000" fetchpriority="high" decoding="async">
				<img class="layer-cup layer-cup-b" src="<?php echo esc_url( $initial['cup'] ); ?>" alt="" width="2400" height="3000" decoding="async">
			</div>
		</div>

		<div class="layer-counter" aria-hidden="true"><span class="layer-counter-current"><?php echo esc_html( str_pad( (string) ( $default_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><i>/</i><span><?php echo esc_html( str_pad( (string) $count, 2, '0', STR_PAD_LEFT ) ); ?></span></div>

		<div class="layer-product-panel">
			<h2 class="layer-product-name"><?php echo esc_html( $initial['label'] ); ?></h2>
			<div class="layer-product-price" aria-live="polite"><?php echo wp_kses_post( $initial_size['priceHtml'] ); ?></div>
			<div class="layer-size-selector" role="group" aria-label="<?php esc_attr_e( 'Drink size', 'layer' ); ?>">
				<?php foreach ( $initial['sizes'] as $size_index => $size ) : ?>
					<button type="button" class="layer-size<?php echo 1 === $size_index ? ' is-selected' : ''; ?>" data-size-index="<?php echo esc_attr( $size_index ); ?>" aria-pressed="<?php echo 1 === $size_index ? 'true' : 'false'; ?>"><?php echo esc_html( $size['label'] ); ?></button>
				<?php endforeach; ?>
			</div>
			<form class="layer-cart-form" action="<?php echo esc_url( $cart_url ); ?>" method="post">
				<input type="hidden" name="add-to-cart" value="<?php echo esc_attr( $initial['productId'] ); ?>">
				<input type="hidden" name="product_id" value="<?php echo esc_attr( $initial['productId'] ); ?>">
				<input type="hidden" name="variation_id" value="<?php echo esc_attr( $initial_size['variationId'] ); ?>">
				<div class="layer-variation-attribute"></div>
				<button class="layer-add-to-cart" type="submit" <?php disabled( ! $initial_size['purchasable'] ); ?>>
					<span class="layer-button-label"><?php echo esc_html( $initial_size['purchasable'] ? $button_prefix . ' — ' . wp_strip_all_tags( $initial_size['priceHtml'] ) : __( 'SET UP PRODUCT', 'layer' ) ); ?></span>
				</button>
			</form>
			<p class="layer-stock-note" aria-live="polite"><?php echo esc_html( $initial['setupMessage'] ); ?></p>
		</div>

		<div class="layer-loader" role="status"><span><?php esc_html_e( 'Loading the drinks…', 'layer' ); ?></span></div>
		<p class="screen-reader-text layer-live-status" aria-live="polite" aria-atomic="true"></p>
	</div>
</section>
