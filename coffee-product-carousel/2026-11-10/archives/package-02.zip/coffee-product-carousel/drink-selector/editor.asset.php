<?php
/**
 * Dependency manifest for the Coffee drink selector editor script.
 *
 * @package Coffee
 */

return array(
	'dependencies' => array(
		'wp-blocks',
		'wp-block-editor',
		'wp-components',
		'wp-core-data',
		'wp-data',
		'wp-element',
	),
	'version'      => '1.0.5',
);
