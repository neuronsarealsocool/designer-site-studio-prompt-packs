<?php
/**
 * Title: Layer homepage editorial scenes
 * Slug: layer/home-sections
 * Categories: layer
 * Inserter: no
 */

$barista     = esc_url( get_theme_file_uri( 'assets/editorial/barista-pour.jpg' ) );
$ingredients = esc_url( get_theme_file_uri( 'assets/editorial/ingredients-counter.jpg' ) );
$shop        = esc_url( get_theme_file_uri( 'assets/editorial/layer-coffee-shop.jpg' ) );
?>
<!-- wp:group {"tagName":"section","anchor":"about","align":"full","className":"layer-editorial-section layer-scene layer-scene--method","layout":{"type":"default"}} -->
<section id="about" class="wp-block-group alignfull layer-editorial-section layer-scene layer-scene--method">
	<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"layer-scene-media"} --><figure class="wp-block-image size-full layer-scene-media"><img src="<?php echo $barista; ?>" alt="Barista pouring milk into an iced Layer coffee" width="2400" height="1600" loading="lazy" decoding="async"></figure><!-- /wp:image -->
	<!-- wp:group {"className":"layer-scene-content","layout":{"type":"constrained"}} -->
	<div class="wp-block-group layer-scene-content">
		<!-- wp:paragraph {"className":"layer-kicker"} --><p class="layer-kicker">THE LAYER METHOD</p><!-- /wp:paragraph -->
		<!-- wp:heading {"level":2,"className":"layer-editorial-title"} --><h2 class="wp-block-heading layer-editorial-title">Built slowly.<br>Tasted all at once.</h2><!-- /wp:heading -->
		<!-- wp:paragraph {"className":"layer-copy"} --><p class="layer-copy">Measured pours. Cold structure. Every layer given time to arrive.</p><!-- /wp:paragraph -->
	</div><!-- /wp:group -->
</section><!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"layer-editorial-section layer-scene layer-scene--ingredients","layout":{"type":"default"}} -->
<section class="wp-block-group alignfull layer-editorial-section layer-scene layer-scene--ingredients">
	<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"layer-scene-media"} --><figure class="wp-block-image size-full layer-scene-media"><img src="<?php echo $ingredients; ?>" alt="Layer coffee ingredients arranged on a brushed-metal counter" width="2400" height="1600" loading="lazy" decoding="async"></figure><!-- /wp:image -->
	<!-- wp:group {"className":"layer-scene-content","layout":{"type":"constrained"}} -->
	<div class="wp-block-group layer-scene-content">
		<!-- wp:paragraph {"className":"layer-kicker"} --><p class="layer-kicker">INGREDIENTS IN FOCUS</p><!-- /wp:paragraph -->
		<!-- wp:heading {"level":2,"className":"layer-editorial-title"} --><h2 class="wp-block-heading layer-editorial-title">Flavor, without disguise.</h2><!-- /wp:heading -->
		<!-- wp:paragraph {"className":"layer-copy"} --><p class="layer-copy">Caramel. Cacao. Strawberry. Pistachio. Brown sugar and spice.</p><!-- /wp:paragraph -->
		<!-- wp:buttons {"className":"layer-quiet-button"} --><div class="wp-block-buttons layer-quiet-button"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/shop/">Explore the drinks</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
	</div><!-- /wp:group -->
</section><!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"layer-editorial-section layer-scene layer-scene--place","layout":{"type":"default"}} -->
<section class="wp-block-group alignfull layer-editorial-section layer-scene layer-scene--place">
	<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"layer-scene-media"} --><figure class="wp-block-image size-full layer-scene-media"><img src="<?php echo $shop; ?>" alt="Layer coffee shop glowing warmly at night" width="2400" height="1600" loading="lazy" decoding="async"></figure><!-- /wp:image -->
	<!-- wp:group {"className":"layer-scene-content","layout":{"type":"constrained"}} -->
	<div class="wp-block-group layer-scene-content">
		<!-- wp:paragraph {"className":"layer-kicker"} --><p class="layer-kicker">AFTER DARK</p><!-- /wp:paragraph -->
		<!-- wp:heading {"level":2,"className":"layer-editorial-title"} --><h2 class="wp-block-heading layer-editorial-title">A quiet corner for layered coffee.</h2><!-- /wp:heading -->
		<!-- wp:paragraph {"className":"layer-copy"} --><p class="layer-copy">Careful pours and the warm hum of a room designed to let the coffee lead.</p><!-- /wp:paragraph -->
		<!-- wp:buttons {"className":"layer-quiet-button"} --><div class="wp-block-buttons layer-quiet-button"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Plan a visit</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
	</div><!-- /wp:group -->
</section><!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"layer-editorial-section layer-scene layer-scene--cta","layout":{"type":"default"}} -->
<section class="wp-block-group alignfull layer-editorial-section layer-scene layer-scene--cta">
	<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"layer-scene-media"} --><figure class="wp-block-image size-full layer-scene-media"><img src="<?php echo $ingredients; ?>" alt="Layer ingredients on a brushed-metal counter" width="2400" height="1600" loading="lazy" decoding="async"></figure><!-- /wp:image -->
	<!-- wp:group {"className":"layer-scene-content","layout":{"type":"constrained"}} -->
	<div class="wp-block-group layer-scene-content">
		<!-- wp:paragraph {"className":"layer-kicker"} --><p class="layer-kicker">YOUR NEXT LAYER</p><!-- /wp:paragraph -->
		<!-- wp:heading {"level":2,"className":"layer-editorial-title"} --><h2 class="wp-block-heading layer-editorial-title">Start with the flavor you know.</h2><!-- /wp:heading -->
		<!-- wp:buttons {"className":"layer-quiet-button"} --><div class="wp-block-buttons layer-quiet-button"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/shop/">Shop Layer</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
	</div><!-- /wp:group -->
</section><!-- /wp:group -->
