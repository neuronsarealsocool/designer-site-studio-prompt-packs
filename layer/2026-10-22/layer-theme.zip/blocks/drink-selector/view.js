(function () {
  'use strict';

  var roots = document.querySelectorAll('.layer-drink-selector');
  roots.forEach(initSelector);

  function initSelector(root) {
    var dataNode = root.querySelector('.layer-selector-data');
    if (!dataNode) return;

    var config;
    try { config = JSON.parse(dataNode.textContent); } catch (error) { return; }
    if (!config.drinks || !config.drinks.length) return;

    var drinks = config.drinks;
    var total = drinks.length;
    var ingredientButtons = Array.prototype.slice.call(root.querySelectorAll('.layer-ingredient'));
    var prevButton = root.querySelector('.layer-arrow-prev');
    var nextButton = root.querySelector('.layer-arrow-next');
    var cupLayers = [root.querySelector('.layer-cup-a'), root.querySelector('.layer-cup-b')];
    var nameNode = root.querySelector('.layer-product-name');
    var priceNode = root.querySelector('.layer-product-price');
    var sizeGroup = root.querySelector('.layer-size-selector');
    var cartForm = root.querySelector('.layer-cart-form');
    var cartButton = root.querySelector('.layer-add-to-cart');
    var buttonLabel = root.querySelector('.layer-button-label');
    var stockNote = root.querySelector('.layer-stock-note');
    var counter = root.querySelector('.layer-counter-current');
    var attributeHolder = root.querySelector('.layer-variation-attribute');
    var liveStatus = root.querySelector('.layer-live-status');
    var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    var activeIndex = clampIndex(config.defaultIndex || 0);
    var pendingIndex = null;
    var virtualCenter = activeIndex;
    var selectedSize = 1;
    var visibleCupLayer = 0;
    var locked = true;
    var touchStart = null;

    applySlots(activeIndex, false);
    updateProduct(activeIndex, selectedSize, false);
    preloadHeroAssets().then(function () {
      locked = false;
      root.classList.remove('is-loading', 'is-locked');
      root.classList.add('is-ready');
      updateControls();
      liveStatus.textContent = 'Layer drink selector ready. ' + drinks[activeIndex].label + ' selected.';
    });

    prevButton.addEventListener('click', function () { requestNavigation(mod(activeIndex - 1, total)); });
    nextButton.addEventListener('click', function () { requestNavigation(mod(activeIndex + 1, total)); });
    ingredientButtons.forEach(function (button) {
      button.addEventListener('click', function () { requestNavigation(Number(button.dataset.index)); });
    });
    sizeGroup.addEventListener('click', function (event) {
      var button = event.target.closest('.layer-size');
      if (!button || button.disabled) return;
      selectedSize = Number(button.dataset.sizeIndex);
      updateSize(drinks[activeIndex], selectedSize, true);
    });
    root.addEventListener('keydown', function (event) {
      if (event.key === 'ArrowLeft') { event.preventDefault(); requestNavigation(mod(activeIndex - 1, total)); }
      if (event.key === 'ArrowRight') { event.preventDefault(); requestNavigation(mod(activeIndex + 1, total)); }
    });
    root.addEventListener('touchstart', function (event) {
      if (event.touches.length !== 1 || locked) return;
      touchStart = { x: event.touches[0].clientX, y: event.touches[0].clientY };
    }, { passive: true });
    root.addEventListener('touchend', function (event) {
      if (!touchStart || locked || !event.changedTouches.length) return;
      var dx = event.changedTouches[0].clientX - touchStart.x;
      var dy = event.changedTouches[0].clientY - touchStart.y;
      touchStart = null;
      if (Math.abs(dx) > 48 && Math.abs(dx) > Math.abs(dy) * 1.3) {
        requestNavigation(mod(activeIndex + (dx < 0 ? 1 : -1), total));
      }
    }, { passive: true });

    function clampIndex(index) { return Math.max(0, Math.min(Number(index) || 0, total - 1)); }
    function mod(value, divisor) { return ((value % divisor) + divisor) % divisor; }
    function wait(ms) { return new Promise(function (resolve) { window.setTimeout(resolve, ms); }); }

    function prepareCup(index, layerIndex) {
      var image = cupLayers[layerIndex];
      image.classList.remove('is-entering');
      image.src = drinks[index].cup;
      if (typeof image.decode === 'function') {
        return image.decode().catch(function () {});
      }
      if (image.complete) return Promise.resolve();
      return new Promise(function (resolve) {
        image.addEventListener('load', resolve, { once: true });
        image.addEventListener('error', resolve, { once: true });
      });
    }

    function waitForIngredientArrival(index, fallbackMs) {
      var button = ingredientButtons.find(function (item) { return Number(item.dataset.index) === index; });
      if (!button || reducedMotion.matches) return wait(fallbackMs);

      return new Promise(function (resolve) {
        var finished = false;
        var timer = window.setTimeout(finish, fallbackMs + 120);

        function finish() {
          if (finished) return;
          finished = true;
          window.clearTimeout(timer);
          button.removeEventListener('transitionend', onTransitionEnd);
          resolve();
        }

        function onTransitionEnd(event) {
          if (event.target === button && event.propertyName === 'left') finish();
        }

        button.addEventListener('transitionend', onTransitionEnd);
      });
    }

    function slotFor(index, center) {
      var difference = mod(index - center, total);
      var half = Math.floor(total / 2);
      return difference <= half ? difference : difference - total;
    }

    function applySlots(center, animate) {
      ingredientButtons.forEach(function (button) {
        var oldSlot = Number(button.dataset.slot);
        var newSlot = slotFor(Number(button.dataset.index), center);
        if (animate && ((oldSlot === -2 && newSlot === 2) || (oldSlot === 2 && newSlot === -2))) {
          button.animate(
            [{ opacity: 1 }, { opacity: 0, offset: .22 }, { opacity: 0, offset: .78 }, { opacity: 1 }],
            { duration: config.travelMs || 560, easing: 'linear' }
          );
        }
        button.dataset.slot = String(newSlot);
        button.classList.toggle('is-center', newSlot === 0);
        button.setAttribute('aria-hidden', newSlot === 0 ? 'true' : 'false');
      });
      updateControls();
    }

    async function requestNavigation(target) {
      target = clampIndex(target);
      if (locked || target === activeIndex) return;

      locked = true;
      pendingIndex = target;
      virtualCenter = activeIndex;
      root.classList.add('is-locked', 'is-transitioning');
      updateControls();

      var targetSlot = slotFor(target, activeIndex);
      var direction = targetSlot > 0 ? 1 : -1;
      var steps = Math.abs(targetSlot);
      var travel = reducedMotion.matches ? 40 : (config.travelMs || 560);
      var preparedLayer = visibleCupLayer === 0 ? 1 : 0;
      var cupReady = prepareCup(pendingIndex, preparedLayer);

      for (var step = 0; step < steps; step += 1) {
        var arrival = step === steps - 1 ? waitForIngredientArrival(pendingIndex, travel) : wait(travel);
        virtualCenter = mod(virtualCenter + direction, total);
        applySlots(virtualCenter, !reducedMotion.matches);
        await arrival;
      }

      await cupReady;
      await commitPending(preparedLayer);
      pendingIndex = null;
      virtualCenter = activeIndex;
      locked = false;
      root.classList.remove('is-locked', 'is-transitioning');
      updateControls();
    }

    async function commitPending(incomingLayer) {
      if (pendingIndex === null) return;
      var destination = pendingIndex;
      var fade = reducedMotion.matches ? (config.reducedFadeMs || 130) : (config.crossfadeMs || 220);
      var incomingCup = cupLayers[incomingLayer];
      var outgoingCup = cupLayers[visibleCupLayer];

      activeIndex = destination;
      selectedSize = preferredSize(drinks[destination]);
      updateProduct(activeIndex, selectedSize, true);
      counter.textContent = String(activeIndex + 1).padStart(2, '0');

      incomingCup.classList.add('is-entering');
      void incomingCup.offsetWidth;
      incomingCup.classList.add('is-visible');
      await wait(fade);
      outgoingCup.classList.add('is-resetting');
      outgoingCup.classList.remove('is-visible');
      incomingCup.classList.remove('is-entering');
      visibleCupLayer = incomingLayer;
      outgoingCup.src = drinks[destination].cup;
      void outgoingCup.offsetWidth;
      outgoingCup.classList.remove('is-resetting');
      liveStatus.textContent = drinks[destination].label + ' selected. ' + plainText(drinks[destination].sizes[selectedSize].priceHtml) + '.';
    }

    function preferredSize(drink) {
      if (drink.sizes[1] && drink.sizes[1].purchasable) return 1;
      for (var index = 0; index < drink.sizes.length; index += 1) {
        if (drink.sizes[index].purchasable) return index;
      }
      return Math.min(1, drink.sizes.length - 1);
    }

    function updateProduct(index, sizeIndex, announce) {
      var drink = drinks[index];
      nameNode.textContent = drink.label;
      sizeGroup.innerHTML = '';
      drink.sizes.forEach(function (size, position) {
        var button = document.createElement('button');
        button.type = 'button';
        button.className = 'layer-size' + (position === sizeIndex ? ' is-selected' : '');
        button.dataset.sizeIndex = String(position);
        button.setAttribute('aria-pressed', position === sizeIndex ? 'true' : 'false');
        button.disabled = !size.inStock;
        button.textContent = size.label;
        sizeGroup.appendChild(button);
      });
      updateSize(drink, sizeIndex, announce);
    }

    function updateSize(drink, sizeIndex, announce) {
      var size = drink.sizes[sizeIndex] || drink.sizes[0];
      selectedSize = sizeIndex;
      Array.prototype.forEach.call(sizeGroup.querySelectorAll('.layer-size'), function (button, index) {
        var chosen = index === sizeIndex;
        button.classList.toggle('is-selected', chosen);
        button.setAttribute('aria-pressed', chosen ? 'true' : 'false');
      });
      priceNode.innerHTML = size.priceHtml;
      cartForm.elements['add-to-cart'].value = drink.productId || '';
      cartForm.elements.product_id.value = drink.productId || '';
      cartForm.elements.variation_id.value = size.variationId || '';
      attributeHolder.innerHTML = '';
      if (size.attributeName && size.attributeValue) {
        var input = document.createElement('input');
        input.type = 'hidden';
        input.name = size.attributeName;
        input.value = size.attributeValue;
        attributeHolder.appendChild(input);
      }
      cartButton.disabled = !size.purchasable;
      if (!size.inStock) {
        buttonLabel.textContent = 'SOLD OUT';
        stockNote.textContent = 'Sold out';
      } else if (!size.purchasable) {
        buttonLabel.textContent = 'SET UP PRODUCT';
        stockNote.textContent = drink.setupMessage || 'This selection is not currently purchasable.';
      } else {
        buttonLabel.textContent = config.buttonPrefix + ' — ' + plainText(size.priceHtml);
        stockNote.textContent = '';
      }
      if (announce) liveStatus.textContent = size.label + ', ' + plainText(size.priceHtml) + (size.inStock ? '' : ', sold out');
    }

    function updateControls() {
      prevButton.disabled = locked || total < 2;
      nextButton.disabled = locked || total < 2;
      ingredientButtons.forEach(function (button) {
        button.disabled = locked || Number(button.dataset.slot) === 0;
      });
    }

    function plainText(html) {
      var node = document.createElement('div');
      node.innerHTML = html || '';
      return node.textContent.trim();
    }

    function preloadHeroAssets() {
      var urls = [];
      drinks.forEach(function (drink) { urls.push(drink.cup, drink.ingredient); });
      return Promise.allSettled(urls.map(function (url) {
        return new Promise(function (resolve) {
          var image = new Image();
          image.onload = resolve;
          image.onerror = resolve;
          image.src = url;
          if (image.complete) resolve();
        });
      }));
    }
  }
}());
