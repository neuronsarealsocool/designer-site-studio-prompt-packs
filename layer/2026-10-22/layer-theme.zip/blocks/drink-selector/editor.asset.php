<?php
/**
 * Dependency manifest for the Layer drink selector editor script.
 *
 * @package Layer
 */

return array(
	'dependencies' => array(
		'wp-blocks',
		'wp-block-editor',
		'wp-components',
		'wp-core-data',
		'wp-data',
		'wp-element',
	),
	'version'      => '1.0.5',
);
