(function (blocks, blockEditor, components, element, data) {
  'use strict';

  var el = element.createElement;
  var Fragment = element.Fragment;
  var InspectorControls = blockEditor.InspectorControls;
  var MediaUpload = blockEditor.MediaUpload;
  var MediaUploadCheck = blockEditor.MediaUploadCheck;
  var useBlockProps = blockEditor.useBlockProps;
  var PanelBody = components.PanelBody;
  var TextControl = components.TextControl;
  var SelectControl = components.SelectControl;
  var Button = components.Button;
  var ColorPalette = components.ColorPalette;
  var Notice = components.Notice;
  var settings = window.layerDrinkSelectorEditor || { defaults: [], background: '' };

  blocks.registerBlockType('layer/drink-selector', {
    apiVersion: 3,
    title: 'Layer Drink Selector',
    category: 'layer',
    icon: 'coffee',
    description: 'Interactive Layer hero with WooCommerce variable-product mapping.',
    attributes: {
      defaultIndex: { type: 'number', default: 1 },
      drinks: { type: 'array', default: [] },
      buttonPrefix: { type: 'string', default: 'ADD TO CART' },
      accentColor: { type: 'string', default: '#a64f18' },
      textColor: { type: 'string', default: '#201812' }
    },
    supports: { align: ['full'], anchor: true, html: false, spacing: { margin: true } },
    edit: function (props) {
      var attributes = props.attributes;
      var setAttributes = props.setAttributes;
      var drinks = attributes.drinks && attributes.drinks.length ? attributes.drinks : settings.defaults;
      var products = data.useSelect(function (select) {
        if (!settings.wooActive) return [];
        return select('core').getEntityRecords('postType', 'product', { per_page: 100, status: 'publish' }) || [];
      }, []);
      var productOptions = [{ label: 'Choose a variable product…', value: 0 }].concat(products.map(function (product) {
        return { label: product.title && product.title.rendered ? product.title.rendered : 'Product #' + product.id, value: product.id };
      }));
      var defaultIndex = Math.min(attributes.defaultIndex || 0, Math.max(0, drinks.length - 1));
      var selected = drinks[defaultIndex] || drinks[0] || {};
      var blockProps = useBlockProps({
        className: 'layer-editor-preview',
        style: {
          backgroundImage: settings.background ? 'url(' + settings.background + ')' : undefined,
          color: attributes.textColor || '#201812'
        }
      });

      function persist(next) {
        setAttributes({ drinks: next, defaultIndex: Math.min(defaultIndex, Math.max(0, next.length - 1)) });
      }

      function updateEntry(index, patch) {
        var next = drinks.map(function (drink, position) {
          return position === index ? Object.assign({}, drink, patch) : drink;
        });
        persist(next);
      }

      function updateSizeLabel(index, sizeIndex, value) {
        var labels = (drinks[index].sizeLabels || ['12 OZ', '16 OZ', '20 OZ']).slice(0, 3);
        while (labels.length < 3) labels.push('');
        labels[sizeIndex] = value;
        updateEntry(index, { sizeLabels: labels });
      }

      function moveEntry(index, direction) {
        var destination = index + direction;
        if (destination < 0 || destination >= drinks.length) return;
        var next = drinks.slice();
        var moved = next.splice(index, 1)[0];
        next.splice(destination, 0, moved);
        persist(next);
      }

      function removeEntry(index) {
        if (drinks.length <= 2) return;
        persist(drinks.filter(function (_, position) { return position !== index; }));
      }

      function addEntry() {
        if (drinks.length >= 5) return;
        var fallback = settings.defaults[drinks.length] || settings.defaults[0] || {};
        persist(drinks.concat([Object.assign({}, fallback, { label: fallback.label || 'New drink', productId: 0 })]));
      }

      function mediaControl(entry, index, kind) {
        var isCup = kind === 'cup';
        var idKey = isCup ? 'cupId' : 'ingredientId';
        var urlKey = isCup ? 'cupUrl' : 'ingredientUrl';
        return el('div', { className: 'layer-editor-entry__media-control' },
          entry[urlKey] ? el('img', { className: 'layer-editor-entry__thumb', src: entry[urlKey], alt: '' }) : null,
          el(MediaUploadCheck, {},
            el(MediaUpload, {
              allowedTypes: ['image'],
              value: entry[idKey] || 0,
              onSelect: function (media) {
                var patch = {};
                patch[idKey] = media.id;
                patch[urlKey] = media.url;
                updateEntry(index, patch);
              },
              render: function (mediaProps) {
                return el(Button, { variant: 'secondary', onClick: mediaProps.open }, entry[urlKey] ? 'Replace ' + kind : 'Choose ' + kind);
              }
            })
          )
        );
      }

      var inspectorEntries = drinks.map(function (entry, index) {
        var labels = entry.sizeLabels || ['12 OZ', '16 OZ', '20 OZ'];
        return el('div', { className: 'layer-editor-entry', key: index },
          el('div', { className: 'layer-editor-entry__head' },
            el('span', {}, String(index + 1).padStart(2, '0') + ' — ' + (entry.label || 'Untitled drink')),
            el('div', { className: 'layer-editor-entry__actions' },
              el(Button, { size: 'small', icon: 'arrow-up-alt2', label: 'Move up', disabled: index === 0, onClick: function () { moveEntry(index, -1); } }),
              el(Button, { size: 'small', icon: 'arrow-down-alt2', label: 'Move down', disabled: index === drinks.length - 1, onClick: function () { moveEntry(index, 1); } }),
              el(Button, { size: 'small', icon: 'trash', label: 'Remove', isDestructive: true, disabled: drinks.length <= 2, onClick: function () { removeEntry(index); } })
            )
          ),
          el(TextControl, { label: 'Displayed drink label', value: entry.label || '', onChange: function (value) { updateEntry(index, { label: value }); } }),
          el(SelectControl, { label: 'WooCommerce variable product', value: entry.productId || 0, options: productOptions, onChange: function (value) { updateEntry(index, { productId: Number(value) }); } }),
          el('div', { className: 'layer-editor-entry__media' }, mediaControl(entry, index, 'cup'), mediaControl(entry, index, 'ingredient')),
          [0, 1, 2].map(function (sizeIndex) {
            return el(TextControl, { key: sizeIndex, label: 'Visible size ' + (sizeIndex + 1), value: labels[sizeIndex] || '', onChange: function (value) { updateSizeLabel(index, sizeIndex, value); } });
          })
        );
      });

      return el(Fragment, {},
        el(InspectorControls, {},
          el(PanelBody, { title: 'Hero settings', initialOpen: true },
            el(SelectControl, {
              label: 'Default drink',
              value: defaultIndex,
              options: drinks.map(function (drink, index) { return { label: String(index + 1).padStart(2, '0') + ' — ' + drink.label, value: index }; }),
              onChange: function (value) { setAttributes({ defaultIndex: Number(value) }); }
            }),
            el(TextControl, { label: 'Purchase button prefix', value: attributes.buttonPrefix || 'ADD TO CART', onChange: function (value) { setAttributes({ buttonPrefix: value }); } }),
            el('p', {}, 'Accent color'),
            el(ColorPalette, { value: attributes.accentColor, colors: [{ name: 'Caramel', color: '#a64f18' }, { name: 'Espresso', color: '#201812' }, { name: 'Taupe', color: '#9d7254' }], onChange: function (value) { setAttributes({ accentColor: value || '#a64f18' }); } }),
            el('p', {}, 'Text color'),
            el(ColorPalette, { value: attributes.textColor, colors: [{ name: 'Espresso', color: '#201812' }, { name: 'Deep brown', color: '#34251b' }, { name: 'Black', color: '#111111' }], onChange: function (value) { setAttributes({ textColor: value || '#201812' }); } })
          ),
          el(PanelBody, { title: 'Drinks and products', initialOpen: false },
            products.length ? null : el(Notice, { status: 'info', isDismissible: false }, 'No WooCommerce products are available yet. Import the starter CSV, then map each entry.'),
            inspectorEntries,
            el(Button, { variant: 'secondary', disabled: drinks.length >= 5, onClick: addEntry }, drinks.length >= 5 ? 'Five-position design is full' : 'Add drink entry')
          )
        ),
        el('div', blockProps,
          selected.cupUrl ? el('img', { className: 'layer-editor-preview__cup', src: selected.cupUrl, alt: '' }) : null,
          el('h2', { className: 'layer-editor-preview__title' }, selected.label || 'Layer drink'),
          el('p', { className: 'layer-editor-preview__note' }, 'Interactive preview appears on the front end · ' + drinks.length + ' drinks')
        )
      );
    },
    save: function () { return null; }
  });
}(window.wp.blocks, window.wp.blockEditor, window.wp.components, window.wp.element, window.wp.data));
