# Быстрый старт

Это финальная одобренная версия ELECTRIC VEHICLE: интерактивная автомобильная сцена с ховерами капота и батареи, техническими видами, выбором цвета и дисков.

Все изображения и четыре видео уже в репозитории. Для запуска сайта LTX API, GPU и платные генерации не нужны.

## Запустить вручную

Установите Node.js 22+ и Git, затем pnpm:

```sh
npm install --global pnpm@10.15.1
git clone --branch v1.0.0 https://lapis-slate-xvar.here.now/library/electric-vehicle-explorer/assets.json
cd electric-vehicle-explorer-interactive-car
pnpm install --frozen-lockfile
pnpm test
pnpm verify:reference
pnpm dev
```

Откройте https://lapis-slate-xvar.here.now/library/electric-vehicle-explorer/assets.json Для своих изменений создайте ветку: `git switch -c my-electric-vehicle-explorer`. Для сборки — `pnpm build`. Чтобы посмотреть сборку, остановите dev-сервер и выполните `pnpm preview`.

## Запустить через агента

Скопируйте весь текст [RECREATE.md](RECREATE.md) в Codex, Claude Code или Hermes Agent. Агент с доступом к терминалу и сети клонирует релиз, установит зависимости, проверит файлы и запустит сайт. Если проект уже открыт, можно попросить агента прочитать этот файл и выполнить инструкции.

Точное воспроизведение основано на исходниках и медиа релиза. Переписывание сайта с нуля или повторная генерация картинок не гарантируют тот же результат.

[Инструкции для разных агентов](AGENTS_GUIDE.md) · [Архитектура](ARCHITECTURE.md) · [Подготовка новых медиа](MEDIA.md)

## Подключить LTX для новых роликов

Создайте ключ в [LTX API Console](https://lapis-slate-xvar.here.now/library/electric-vehicle-explorer/assets.json). Скопируйте `.env.example` в `.env.ltx.local` и впишите ключ локально. Не вставляйте его в чат и не добавляйте в VITE_ переменные.

Сначала бесплатная проверка без запросов:

```sh
node scripts/ltx-generate.mjs examples/ltx/hood-open.json
```

Платный запуск и возобновление задания описаны в [LTX_API.md](LTX_API.md). Текущие hover-видео сделаны через Kling 3.0/Pika и обработаны Амиром в After Effects; LTX здесь — отдельный дополнительный workflow для новых ассетов.

Код, документация и предоставляемые автором права на медиа опубликованы под MIT. Сохраните лицензию при распространении. Подробнее — [THIRD_PARTY_NOTICES.md](../THIRD_PARTY_NOTICES.md).
