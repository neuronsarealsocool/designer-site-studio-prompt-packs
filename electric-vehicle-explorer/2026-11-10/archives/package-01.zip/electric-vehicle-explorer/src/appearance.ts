export type AppearanceMode = 'paint' | 'wheels'
export const baseExterior = '/media/162e2a3e090740.png'
export type AppearanceOption = { id: string; label: string; image: string; color?: string }
export const appearanceOptions: Record<AppearanceMode, AppearanceOption[]> = {
  paint: [
    { id: 'silver', label: 'Studio Silver', color: '#c9cfd2', image: baseExterior },
    { id: 'electric', label: 'Electric Green', color: '#edff39', image: '/media/config/1306e84e815645.png' },
    { id: 'lime', label: 'Lime Green', color: '#9fdc32', image: '/media/config/6a94dcf4b0d544.png' },
    { id: 'sky', label: 'Sky Blue', color: '#708fa2', image: '/media/config/f59c5bf239c241.png' },
    { id: 'graphite', label: 'Graphite', color: '#30363c', image: '/media/config/1b5da2ffbc1f42.png' },
  ],
  wheels: [
    { id: 'original', label: 'Multi-spoke', image: baseExterior },
    { id: 'aero', label: 'Aero Disc', image: '/media/config/b6360b840df84c.png' },
    { id: 'forged', label: 'Sport Forged', image: '/media/config/4eced439fce249.png' },
  ],
}

export function canUseHotspot(active: AppearanceMode | null, id: string, closing: boolean) {
  return !closing && (!active || active === id)
}
