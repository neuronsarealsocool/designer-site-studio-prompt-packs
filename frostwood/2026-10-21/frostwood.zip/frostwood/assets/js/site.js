(function () {
  'use strict';

  function initGallery(viewport) {
    var track = viewport.querySelector('.frostwood-film-track');
    var original = viewport.querySelector('.frostwood-film-sequence');
    if (!track || !original || track.querySelector('[data-frostwood-clone]')) return;

    var clone = original.cloneNode(true);
    clone.setAttribute('aria-hidden', 'true');
    clone.setAttribute('data-frostwood-clone', 'true');
    clone.querySelectorAll('img').forEach(function (image) { image.alt = ''; });
    track.appendChild(clone);

    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    var width = 0;
    var offset = 0;
    var last = performance.now();
    var frame = 0;
    var paused = false;
    var dragging = false;
    var pointerStart = 0;
    var dragStart = 0;
    var speed = 58;

    function normalize() {
      if (!width) return;
      while (offset <= -width) offset += width;
      while (offset > 0) offset -= width;
    }
    function draw() { track.style.transform = 'translate3d(' + offset + 'px,0,0)'; }
    function measure() { width = original.getBoundingClientRect().width; normalize(); draw(); }
    function tick(now) {
      var elapsed = Math.min(now - last, 64);
      last = now;
      if (!reduced.matches && !paused && !dragging && width) {
        offset -= speed * (elapsed / 1000);
        normalize();
        draw();
      }
      frame = requestAnimationFrame(tick);
    }
    function setMotionMode() {
      viewport.dataset.reducedMotion = reduced.matches ? 'true' : 'false';
      if (reduced.matches) { offset = 0; draw(); }
      last = performance.now();
    }
    function pointerUp(event) {
      if (!dragging) return;
      dragging = false;
      viewport.classList.remove('is-dragging');
      if (viewport.hasPointerCapture(event.pointerId)) viewport.releasePointerCapture(event.pointerId);
      last = performance.now();
    }

    viewport.addEventListener('mouseenter', function () { paused = true; });
    viewport.addEventListener('mouseleave', function () { paused = false; last = performance.now(); });
    viewport.addEventListener('pointerdown', function (event) {
      if (reduced.matches) return;
      dragging = true;
      pointerStart = event.clientX;
      dragStart = offset;
      viewport.classList.add('is-dragging');
      viewport.setPointerCapture(event.pointerId);
    });
    viewport.addEventListener('pointermove', function (event) {
      if (!dragging) return;
      offset = dragStart + event.clientX - pointerStart;
      normalize();
      draw();
    });
    viewport.addEventListener('pointerup', pointerUp);
    viewport.addEventListener('pointercancel', pointerUp);
    reduced.addEventListener('change', setMotionMode);
    new ResizeObserver(measure).observe(original);
    setMotionMode();
    measure();
    frame = requestAnimationFrame(tick);

    window.addEventListener('pagehide', function () { cancelAnimationFrame(frame); }, { once: true });
  }

  function initNavigation() {
    var shell = document.querySelector('.frostwood-nav-shell');
    if (!shell) return;
    document.addEventListener('pointerdown', function (event) {
      if (shell.contains(event.target)) return;
      var close = shell.querySelector('.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__responsive-container-close');
      if (close) close.click();
    });
    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape') return;
      var close = shell.querySelector('.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__responsive-container-close');
      if (close) close.click();
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.frostwood-film-viewport').forEach(initGallery);
    initNavigation();
  });
}());

