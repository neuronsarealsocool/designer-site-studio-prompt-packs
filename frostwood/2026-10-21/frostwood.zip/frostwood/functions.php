<?php
/**
 * Frostwood theme setup.
 *
 * @package Frostwood
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function frostwood_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/site.css' );
}
add_action( 'after_setup_theme', 'frostwood_setup' );

function frostwood_assets() {
	$theme = wp_get_theme();
	wp_enqueue_style( 'frostwood-site', get_theme_file_uri( '/assets/css/site.css' ), array(), $theme->get( 'Version' ) );
	wp_enqueue_script( 'frostwood-site', get_theme_file_uri( '/assets/js/site.js' ), array(), $theme->get( 'Version' ), true );
}
add_action( 'wp_enqueue_scripts', 'frostwood_assets' );

function frostwood_pattern_categories() {
	register_block_pattern_category( 'frostwood', array( 'label' => __( 'Frostwood', 'frostwood' ) ) );
}
add_action( 'init', 'frostwood_pattern_categories' );

