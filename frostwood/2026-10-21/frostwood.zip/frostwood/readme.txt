=== Frostwood ===
Contributors: frostwood
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

A responsive Gutenberg block theme for the Frostwood premium winter cabin retreat.

== Installation ==
1. Open WordPress Admin.
2. Go to Appearance > Themes.
3. Select Add New.
4. Select Upload Theme.
5. Choose frostwood.zip.
6. Install and activate Frostwood.

== Editing ==
Open Appearance > Editor > Templates > Front Page.

The hero, gallery, amenities, interior copy, testimonial, and final CTA are editable core blocks assembled from Frostwood patterns. Edit the floating navigation and tiny footer under Appearance > Editor > Design > Patterns > Manage My Patterns > Template Parts.

== Notes ==
All production images are bundled locally. The continuous gallery uses a small dependency-free script and respects reduced-motion preferences.
