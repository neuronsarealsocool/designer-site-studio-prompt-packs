<?php
/**
 * Title: Night exterior quote
 * Slug: frostwood/exterior
 * Categories: frostwood
 * Inserter: yes
 */
$exterior = esc_url( get_theme_file_uri( '/assets/images/exterior.webp' ) );
?>
<!-- wp:cover {"url":"<?php echo $exterior; ?>","dimRatio":35,"overlayColor":"charcoal","minHeight":100,"minHeightUnit":"svh","className":"frostwood-exterior","layout":{"type":"constrained"}} -->
<div class="wp-block-cover frostwood-exterior" style="min-height:100svh"><span aria-hidden="true" class="wp-block-cover__background has-charcoal-background-color has-background-dim-35 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Frostwood cabin glowing across a dark alpine lake beneath the Milky Way" src="<?php echo $exterior; ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:quote {"className":"frostwood-image-quote"} --><blockquote class="wp-block-quote frostwood-image-quote"><!-- wp:paragraph --><p>“We didn’t want to leave. Snow on the trees,<br>stars overhead, and the quiet we’d been<br>chasing for so long.”</p><!-- /wp:paragraph --><cite>Alex &amp; Jordan · January</cite></blockquote><!-- /wp:quote --></div></div>
<!-- /wp:cover -->

