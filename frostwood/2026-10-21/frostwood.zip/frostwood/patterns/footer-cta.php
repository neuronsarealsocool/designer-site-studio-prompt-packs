<?php
/**
 * Title: Booking call to action
 * Slug: frostwood/footer-cta
 * Categories: frostwood
 * Inserter: yes
 */
$footer_image = esc_url( get_theme_file_uri( '/assets/images/footer.webp' ) );
?>
<!-- wp:cover {"url":"<?php echo $footer_image; ?>","dimRatio":40,"overlayColor":"charcoal","minHeight":100,"minHeightUnit":"svh","anchor":"book","className":"frostwood-booking","layout":{"type":"constrained"}} -->
<div class="wp-block-cover frostwood-booking" id="book" style="min-height:100svh"><span aria-hidden="true" class="wp-block-cover__background has-charcoal-background-color has-background-dim-40 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Frostwood cabin glowing among snow-covered pines beneath winter stars" src="<?php echo $footer_image; ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"className":"frostwood-booking-copy","layout":{"type":"constrained"}} --><div class="wp-block-group frostwood-booking-copy"><!-- wp:heading --><h2 class="wp-block-heading">Slow down.<br>Settle in.<br>Stay awhile.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Winter is waiting.</p><!-- /wp:paragraph --><!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"pine","textColor":"snow","className":"frostwood-button"} --><div class="wp-block-button frostwood-button"><a class="wp-block-button__link has-snow-color has-pine-background-color has-text-color has-background wp-element-button" href="mailto:stay@frostwood.com?subject=Frostwood%20stay%20inquiry">Book your stay</a></div><!-- /wp:button --></div><!-- /wp:buttons --></div><!-- /wp:group --></div></div>
<!-- /wp:cover -->

