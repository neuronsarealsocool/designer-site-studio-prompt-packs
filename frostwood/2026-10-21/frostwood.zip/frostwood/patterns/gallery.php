<?php
/**
 * Title: Moving editorial gallery
 * Slug: frostwood/gallery
 * Categories: frostwood
 * Inserter: yes
 */
$gallery = array(
	array( '/assets/images/navbar/31997.webp', 'A secluded log cabin in warm winter morning light', 1500, 844 ),
	array( '/assets/images/gallery-section/ymrfsf3hq07n9pnworpq.webp', 'Stone terrace with a glowing outdoor fireplace', 1000, 1500 ),
	array( '/assets/images/navbar/2151893107.webp', 'A small cabin surrounded by a snow-filled pine forest', 1500, 1000 ),
	array( '/assets/images/gallery-section/xv4gqtjy1smp7v0noe1y.webp', 'Timber cabin beneath pale winter mountains', 1000, 1500 ),
	array( '/assets/images/gallery-section/xhwwuzoveviu3fnry0ep.webp', 'Warm timber bedroom dressed for winter', 1000, 1500 ),
	array( '/assets/images/gallery-section/vhsufyn4cag4hcjesuz1.webp', 'Cabin lounge overlooking a snow-covered forest', 847, 1500 ),
	array( '/assets/images/gallery-section/qmbvrgf0huyafqgdpt0d.webp', 'Snow-covered log cabin among tall pines', 856, 1500 ),
	array( '/assets/images/navbar/178473.webp', 'A glowing lakeside cabin in a quiet mountain valley', 1500, 844 ),
	array( '/assets/images/gallery-section/nswkijul65laqhp1ufvo.webp', 'Cozy bedroom with a fireplace and forest view', 1000, 1500 ),
	array( '/assets/images/gallery-section/m4nfqolbt9sq0a9znreq.webp', 'Bedroom with a fireplace and snowy lake view', 1000, 1500 ),
	array( '/assets/images/gallery-section/lkp1c7pouxlakqoje01o.webp', 'Soft bed beside a sunlit winter window', 1000, 1500 ),
	array( '/assets/images/gallery-section/kmqqusnhtgbjru2bm0dd.webp', 'Airy timber cabin interior and staircase', 1000, 1500 ),
	array( '/assets/images/gallery-section/kketuzn3fftyylx9dqsm.webp', 'Golden lounge beneath a picture window', 841, 1500 ),
);
?>
<!-- wp:group {"tagName":"section","anchor":"gallery","className":"frostwood-gallery-section","layout":{"type":"default"}} -->
<section class="wp-block-group frostwood-gallery-section" id="gallery"><!-- wp:group {"className":"frostwood-gallery-label-row","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} --><div class="wp-block-group frostwood-gallery-label-row"><!-- wp:paragraph {"className":"frostwood-section-label"} --><p class="frostwood-section-label">02 / Inside Frostwood</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Drag to wander · Hover to pause</p><!-- /wp:paragraph --></div><!-- /wp:group -->
<!-- wp:group {"className":"frostwood-film-viewport","layout":{"type":"default"}} --><div class="wp-block-group frostwood-film-viewport" aria-label="Frostwood cabin gallery"><!-- wp:group {"className":"frostwood-film-track","layout":{"type":"flex","flexWrap":"nowrap"}} --><div class="wp-block-group frostwood-film-track"><!-- wp:gallery {"linkTo":"none","className":"frostwood-film-sequence"} -->
<figure class="wp-block-gallery has-nested-images columns-default is-cropped frostwood-film-sequence">
<?php foreach ( $gallery as $image ) : ?>
<!-- wp:image {"width":"auto","height":"100%","sizeSlug":"full","linkDestination":"none"} --><figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_theme_file_uri( $image[0] ) ); ?>" alt="<?php echo esc_attr( $image[1] ); ?>" width="<?php echo esc_attr( $image[2] ); ?>" height="<?php echo esc_attr( $image[3] ); ?>" style="width:auto;height:100%"/></figure><!-- /wp:image -->
<?php endforeach; ?>
</figure>
<!-- /wp:gallery --></div><!-- /wp:group --></div><!-- /wp:group -->
<!-- wp:group {"className":"frostwood-gallery-statement","layout":{"type":"constrained"}} --><div class="wp-block-group frostwood-gallery-statement"><!-- wp:heading --><h2 class="wp-block-heading">Every window opens into winter.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Cedar walls, soft light and a place that holds space for doing nothing at all.</p><!-- /wp:paragraph --></div><!-- /wp:group --></section>
<!-- /wp:group -->

