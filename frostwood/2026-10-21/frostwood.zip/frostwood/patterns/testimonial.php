<?php
/**
 * Title: Text testimonial
 * Slug: frostwood/testimonial
 * Categories: frostwood
 * Inserter: yes
 */
?>
<!-- wp:group {"tagName":"section","className":"frostwood-testimonial","layout":{"type":"constrained"}} -->
<section class="wp-block-group frostwood-testimonial"><!-- wp:quote --><blockquote class="wp-block-quote"><!-- wp:paragraph --><p>“Frostwood felt like a private world.<br>The kind of place you keep to yourself.”</p><!-- /wp:paragraph --><cite>Maya T. <span>January</span></cite></blockquote><!-- /wp:quote --></section>
<!-- /wp:group -->

