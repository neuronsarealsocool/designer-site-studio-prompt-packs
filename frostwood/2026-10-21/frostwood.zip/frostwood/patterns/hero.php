<?php
/**
 * Title: Cinematic hero
 * Slug: frostwood/hero
 * Categories: frostwood
 * Inserter: yes
 */
$hero = esc_url( get_theme_file_uri( '/assets/images/hero.webp' ) );
?>
<!-- wp:cover {"url":"<?php echo $hero; ?>","dimRatio":35,"overlayColor":"charcoal","minHeight":100,"minHeightUnit":"svh","className":"frostwood-hero","anchor":"home","layout":{"type":"constrained"}} -->
<div class="wp-block-cover frostwood-hero" id="home" style="min-height:100svh"><span aria-hidden="true" class="wp-block-cover__background has-charcoal-background-color has-background-dim-35 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Frostwood cabin beside a still alpine lake beneath snow-covered mountains" src="<?php echo $hero; ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"className":"frostwood-hero-copy","layout":{"type":"constrained"}} -->
<div class="wp-block-group frostwood-hero-copy"><!-- wp:paragraph {"className":"frostwood-eyebrow"} --><p class="frostwood-eyebrow">A private winter retreat</p><!-- /wp:paragraph --><!-- wp:heading {"level":1} --><h1 class="wp-block-heading">Slow down.<br>Settle into winter.</h1><!-- /wp:heading --><!-- wp:paragraph --><p>An intimate lakeside cabin, wrapped in forest and designed for unhurried days.</p><!-- /wp:paragraph --><!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"snow","textColor":"charcoal","className":"frostwood-button"} --><div class="wp-block-button frostwood-button"><a class="wp-block-button__link has-charcoal-color has-snow-background-color has-text-color has-background wp-element-button" href="#stay">Discover Frostwood</a></div><!-- /wp:button --></div><!-- /wp:buttons --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"frostwood-explore"} --><p class="frostwood-explore"><a href="#stay">Explore <span aria-hidden="true">↓</span></a></p><!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

